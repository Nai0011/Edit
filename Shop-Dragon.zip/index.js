const path = require('path') 
const config = {

    token: "",//  توكن بوتك

    Admin: "1269451365155864628",//ايدي رتبه الصلاحيات
admin2:"1269451341445730325",//هاي ستاف
    log:  "1269458037341687919", 
    words: [

    'بيع',

    'شراء',

    'سعر',

    'عرض',

    'هاك',

    'فيزا',

    'مطلوب',

    'كرديت',

    'متوفر',

    'حساب',

    'شوب',

    'خاص',

    'مقابل'

],

    line: "https://i.postimg.cc/MHPKY3JT/77-20240728145820.webp",//  رابط الخط

prefix:"父︰㇂🛒㇁",//بدايه اسم المتاجر
    
    tax: "1269451462354796639",// روم ضريبه لو ما تبي خليه فاضي
commandlog:  "1269451537499820165",//ايدي روم لوق الأوامر

    

 

help:  "1269451397095755899",// رتبه مساعد

   ord:"1269451485440118829",
    ordrole:"1269451415659610112", 
    auction:"1269451483200622592",
    auction2:'1269451484366504076', 
    staffchannel: "1269451539425136757", 
    staff: "1269451365155864628",
    staff2:"1269451364157755492", 
    mediatorchannel:"1269622443362750464", 
    mediator:"1269451380922257432", 
    mediator2:"1269451382180806698", 
    auctionbuy: "1269451480239312996", 
    price:"1269451481594069073" 

};
const transfer = config.bank
const { QuickDB, JSONDriver } = require("quick.db");
const jsonDriver = new JSONDriver();
const db = new QuickDB({ driver: jsonDriver });
const fs = require('fs')
const {Client, REST, Routes, Collection, PermissionsBitField} = require('discord.js')
const {EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ApplicationCommandOptionType, ChannelType, ActivityType, InteractionResponseType, TextInputStyle, ModalBuilder,TextInputBuilder,ComponentType,
 PermissionOverwriteFlags, permissionOverwrites, StringSelectMenuBuilder, Events, TextChanne,InteractionType, GatewayIntentBits} = require("discord.js");
const {PermissionFlagsBits} = require("discord.js")
const { google } = require('googleapis');
const axios = require('axios');
const express = require('express')
const app = express()
let shrole = `1121776569929707610`
app.get('/', (req, res) => res.send('hi'))
app.listen(4000, () => console.log('app is ready'))
const { QuantumDB } = require('qd.db');
const ms = require('ms');
const  {Partials}  = require('discord.js')
const dbb = new QuantumDB('index.json');//Specify a filed to be the database 
 const client = new Client({
//intents: 3276799,
    intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.DirectMessageReactions,
    GatewayIntentBits.DirectMessageTyping,
    GatewayIntentBits.MessageContent
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.GuildMember,
    Partials.Reaction,
    Partials.GuildScheduledEvent,
    Partials.User,
    Partials.ThreadMember
  ],

})
const client2 = new Client({

    intents: 3276799

})
const types = require('./types.js')
client.types = types
function choices() {
  const ch = []
  for (const t of types) {
    ch.push({
      name: t.name,
      value: t.id
    })
  }
  return ch;  
}
const chsd = choices();
client.commands1 = new Collection();
  
       
const typesPath = path.join(__dirname, 'types.js');
client.on('messageCreate', async message => {
    if (!message.content.startsWith('!set-status')) return;

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    const args = message.content.split(' ').slice(1).join(' ');

    if (!args) {
        return message.reply(`**يـرجـي إسـتـخـدام الأمـر بـالـطـريـقـه الـصـحـيـحـه مـثـال : \n !set-status اسـم الـحـالـه**`);
    }

    const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('streaming')
                .setLabel('Streaming')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('playing')
                .setLabel('Playing')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('watching')
                .setLabel('Watching')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('listening')
                .setLabel('Listening')
                .setStyle(ButtonStyle.Primary)
        );

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('competing')
                .setLabel('Competing')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('custom')
                .setLabel('Custom Status')
                .setStyle(ButtonStyle.Primary)
        );

    const initialMessage = await message.reply({
        content: '**حـدد نـوع الـActivity **',
        components: [row1, row2],
    });

    const filter = interaction => interaction.message.id === initialMessage.id && interaction.user.id === message.author.id;
    const collector = initialMessage.createMessageComponentCollector({ componentType: ComponentType.Button, filter });

    collector.on('collect', async interaction => {
        let activityType;
        let customStatus = false;

        switch (interaction.customId) {
            case 'streaming':
                activityType = ActivityType.Streaming;
                break;
            case 'playing':
                activityType = ActivityType.Playing;
                break;
            case 'watching':
                activityType = ActivityType.Watching;
                break;
            case 'listening':
                activityType = ActivityType.Listening;
                break;
            case 'competing':
                activityType = ActivityType.Competing;
                break;
            case 'custom':
                customStatus = true;
                activityType = ActivityType.Custom;
                break;
        }

        if (interaction.customId === 'streaming') {
            const modal = new ModalBuilder()
                .setCustomId('streamingModal')
                .setTitle('Enter Stream URL')
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('streamingUrl')
                            .setLabel('Stream URL')
                            .setStyle(TextInputStyle.Short)
                            .setPlaceholder('https://www.example.com')
                            .setRequired(true)
                    )
                );

            await interaction.showModal(modal);
        } else if (customStatus) {
            await client.user.setPresence({ activities: [{ name: args, type: ActivityType.Custom }] });
            await interaction.update({
                content: `**تـم وضـع الـحـالـه الـخـاصـة بـنـجـاح  ** \n ** الـحـالـه :__${args}__**`,
                components: [],
            });
        } else {
            const rowStatus = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('online')
                        .setLabel('Online')
                        .setEmoji('🟢')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('invisible')
                        .setLabel('Invisible')
                        .setEmoji('⚪')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('dnd')
                        .setLabel('Do Not Disturb')
                        .setEmoji('🔴')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('idle')
                        .setLabel('Idle')
                        .setEmoji('🌙')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.update({
                content: '**حـدد حـالـة الـبـوت:**',
                components: [rowStatus],
            });

            const collector2 = initialMessage.createMessageComponentCollector({ componentType: ComponentType.Button, filter });

            collector2.on('collect', async interaction2 => {
                const status = interaction2.customId;

                await client.user.setPresence({
                    activities: [{ name: args, type: activityType }],
                    status: status,
                });

                await interaction2.message.edit({
                    content: `**تـم وضـع الـحـالـه بـنـجـاح \n أسـم الـحـالـه :__${args}__ \n الـActivity  :__${interaction.customId}__ \n حـالـه الـبـوت :__${interaction2.customId}__**`,
                    components: [],
               });
            });
        }
    });

    client.on('interactionCreate', async interaction => {
        if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'streamingModal') {
            const streamUrl = interaction.fields.getTextInputValue('streamingUrl');
            const urlPattern = new RegExp('^(https?:\\/\\/)?([\\da-z.-]+)\\.([a-z.]{2,6})([\\/\\w .-]*)*\\/?$');

            if (!urlPattern.test(streamUrl)) {
                return await interaction.reply({ content: '**يـرجـي إدخـال رابـط صـحـيـح**', ephemeral: true });
            }

            await client.user.setPresence({
                activities: [{ name: args, type: ActivityType.Streaming, url: streamUrl }],
                status: 'online',
            });

            await interaction.message.edit({
                content: `**تـم وضـع الـحـالـه بـنـجـاح \n الـحـالـه : __${args}__ \n الـActivity : __Streaming__**`,
                components: [],
            });
        }
    });
});
client.on('channelDelete', async channel => {
       
    let data =  await  db.get(`shop_${channel.id}`)
    if (data)  {
        
     let helpers =    await  db.get(`shop_${channel.id}.partners`)  ||  []
     let type = types.find(type => type.role ===   data.type)
    let owner = await  channel.guild.members.cache.get(data.owner)
   owner.roles.remove(type.role)
    const channels = await channel.guild.channels.fetch();
let rut = [] 
helpers.forEach(async(pom)  =>   {
    
let nj =    await channel.guild.members.cache.get(pom)
await nj.roles.remove(config.help)
                
    
    
    
    })
channels.forEach(async (ch)  =>  {
    
   let dao = await db.get(`shop_${ch.id}`)
   if (dao)  {
   if (dao.owner === data.owner)  {
   let typpe = types.find(type =>  type.role  === data.type) 
   await  owner.roles.add(typpe.role)
       
       
       }
 let mn  = await db.get(`shop_${ch.id}.partners`)  ||  []
 helpers.forEach(async  (hel)  =>   {
     
    if (mn.includes(hel)){ 
        
   rut.push(hel)     
        
        } 
     
     })
} 
    })

  helpers.forEach(async (helper) => {

let helm = await  channel.guild.members.cache.get(helper)
await  helm.roles.remove(config.help)

}) 
        rut.forEach(async (helper) => {
            
  let nigga = await channel.guild.members.cache.get(helper)
  await  nigga.roles.add(config.help)
            
            
            
        })    
        }
       
       
       

})
async function updateCommands() {
const commands = [
    {
      name: 'shop-setup',
      description: 'ارسال تكت الشراء .',
      dm_permission: false,
      default_member_permissions: 8,
    },
    {
      name: 'mentions',
      description: 'عـرض مـنـشـنـات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
    {
      name: 'r-mentions',
      description: 'اعادة تـعـيـيـن مـنـشـنـات المـتـاجـر ',
      dm_permission: false,
      default_member_permissions: 8,
        
        options:[
            {
          name: 'channel',
      description: 'الروم التي تريد ارسال فيها الاشعار',
      type: ApplicationCommandOptionType.Channel,
      required: false,
     channel_types: [ChannelType.GuildText]

            },
              {
                  name: `image`,
                  description: `صورة الأميبد`,
                  type: ApplicationCommandOptionType.String,
                  required: false,
              },
        ]
    },
    {
      name: 'shop-data',
      description: 'عـرض مـعـلـومـات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
        {
      name: 'warns',
      description: 'عـرض تـحـذيـرات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
    {
    name: 'owner',
    description: 'change owner of a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    {
      name: 'new-owner',
      description: 'صـاحـب المـتـجـر الجـديـد',
      type: ApplicationCommandOptionType.User,
      required: true,
    }, 
        {

                  name: `image`,

                  description: `صورة الأميبد`,

                  type: ApplicationCommandOptionType.String,

                  required: false,

              },
    ]
    },
    {
    name: 'warn',
    description: 'warn a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    
        {

      name: 'reason',

      description:'السبب',

      type: ApplicationCommandOptionType.String,

      required: true,

      

    },
        {

  name: 'proof',

  description: 'دلـيـل الـمـخـالـفـه',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
    ]
    },
    {
    name: 'unwarn',
    description: 'unwarn a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    {
      name: 'amount',
      description: 'عـدد التـحـذيـرات',
      type: ApplicationCommandOptionType.Number,
      required: true,
    },
        
{

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}        
    ]
    },
    {
      name: 'add-helper',
      description: ' اضـافـة مساعد للمـتـجـر ',
      dm_permission: false,
      options: [
        {
          name: `helper`,
          description: `المـساعد.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
         }, 
          {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
      ]
    },
    {
      name: 'remove-helper',
      description: ' ازالة مساعد مـن مـتـجـر مـعـيـن ',
      dm_permission: false,
      options: [
        {
          name: `helper`,
          description: `المساعد.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
         }
      ]
    }, 
    { 
    name: 'shop',
    description: 'create a shop',
    dm_permission: false,
    options: [
    {
      name: 'type',
      description: 'نوع المتجر',
      type: ApplicationCommandOptionType.String,
      required: true,
      choices: chsd
    },
    {
      name: 'name',
      description: 'اسم المتجر',
      type: ApplicationCommandOptionType.String,
      required: true,
     // choices: choices()
    },
    {
      name: 'owner',
      description: 'مالك المتجر',
      type: ApplicationCommandOptionType.User,
      required: true,
      //choices: choices()
    }, 
        {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
    ]
    }, 

  
    
     
   
  
    { 

    name: 'delete-shop',

    description: 'لـحـذف مـتـجـر',

    dm_permission: false,


    options:[
        {

        name: 'shop',

        description: 'الـمـتـجـر',

        type: ApplicationCommandOptionType.Channel,

        required: true,

      }, 
        {

        name: 'reason',

        description: 'الـسـبـب',

        type: ApplicationCommandOptionType.String,

        required: true,

      }, 
        {

  name: 'proof',

  description: 'دلـيـل الـمـخـالـفـه',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

},
        
        ] 
        },
    
    {
         
    name: 'add-mentions',

    description: 'إضـافـه مـنـشـنـات لـمـتـجـر',

    dm_permission: false,


    options:[
    
    {

      name: 'shop',

      description: 'الـمـتـجـر',

      type: ApplicationCommandOptionType.Channel,

      required: true,

      //choices: choices()

    }, 
   {

      name: 'everyone',

      description: 'عـدد مـنـشـنـات everyone',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
{

      name: 'here',

      description: 'عـدد مـنـشـنـات here',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
        {

      name: 'shop_mentions',

      description: 'عـدد مـنـشـنـات الـمـتـجـر',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
        {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
        
] 
}, 
    {

         

    name: 'create-request',

    description: 'إنـشـاء طـلـب',

    dm_permission: false,


    options:[

    {

  name: 'owner',

  description: 'صـاحـب الـطـلـب',

  type: ApplicationCommandOptionType.User,

  required: true,

}, 
        {

  name: 'order',

  description:'الـطـلـب',

  type: ApplicationCommandOptionType.String,

  required: true,

}, 
        {

  name: 'time',

  description: 'الـمـده بـالأيـام',

  type: ApplicationCommandOptionType.Number,

  required: true,

}, 
        
        {
  name: 'mention',
  description: 'الـمـنـشـن',
  type: ApplicationCommandOptionType.String,
  required: true,
  choices: [
    {
      name: 'مـنـشـن هـيـر',
      value: 'here'
    },
    {
      name: 'مـنـشـن أفـري',
      value: 'everyone'
    }
  ]
}, 
        {

  name: 'proof',

  description: 'دلـيـل الـتـحـويـل',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}, 
        
        

                
{

  name: 'photo',

  description: 'صـوره',

  type: ApplicationCommandOptionType.Attachment,

  required: false,

}, 
        
        
        
        
        ]
        }, 
    {
    name: 'create-auction',
    description: 'إنـشـاء مـزاد',
    dm_permission: false,
    options: [
        {
            name: 'owner',
            description: 'صـاحـب الـمـزاد',
            type: ApplicationCommandOptionType.User,
            required: true,
        },
        {
            name: 'item',
            description:'الـسـلـعـه',
            type: ApplicationCommandOptionType.String,
            required: true,
        },
        {

            name: 'price',

            description:'الـسـعـر الـبـدائـي',

            type: ApplicationCommandOptionType.String,

            required: true,

        },
        {
            name: 'time',
            description: 'الـمـده بـالـدقـائـق',
            type: ApplicationCommandOptionType.String, 
            required: true,
        },
        {
            name: 'mention',
            description: 'الـمـنـشـن',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'مـنـشـن هـيـر',
                    value: 'here'
                },
                {
                    name: 'مـنـشـن أفـري',
                    value: 'everyone'
                }
            ]
        },
        {

            name: 'tax',

            description: 'الـسـعـر بـالـضـريـبـة؟ ',

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'لا',

                    value: 'لا'

                },

                {

                    name: 'نـعـم',

                    value: 'نـعـم'

                }

            ]

        },
        {
            name: 'channel',
            description: 'روم الـمزاد', 
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'مـزاد 1',
                    value: config.auction 
                },
                {
                    name:'مـزاد 2',
                    value: config.auction2
                }
            ]
        },
        {
            name: 'proof',
            description: 'دلـيـل الـتـحـويـل',
            type: ApplicationCommandOptionType.Attachment,
            required: true,
        },
        {
            name: 'photo1',
            description: 'صـوره 1',
            type: ApplicationCommandOptionType.Attachment,
            required: true,
        },
        {
            name: 'photo2',
            description: 'صـوره 2',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo3',
            description: 'صـوره 3',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo4',
            description: 'صـوره 4',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo5',
            description: 'صـوره 5',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo6',
            description: 'صـوره 6',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo7',
            description: 'صـوره 7',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo8',
            description: 'صـوره 8',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo9',
            description: 'صـوره 9',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
    ]
}, 
    {

         

    name: 'say',

    description: 'إرسـال رسـالـه',

    dm_permission: false,


    options:[

        {

            name: 'embed',

            description: 'الـرسـالـه أيـمـبـد؟ ',

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'لا',

                  value:'false'

                },

                {

                    name: 'نـعـم',

                    value:'true'

                }

            ]

        },
        
       {
           name:'content', 
           description:'مـحـتـوي الـرسـالـه او وصـف الأيـمـبـد', 
           type: ApplicationCommandOptionType.String,

            required: true,
           }, 
        {

           name:'title', 

           description:'عـنـوان الأيـمـبـد', 

           type: ApplicationCommandOptionType.String,

            required: false,

           }, 
        {

           name:'image', 

           description:'صـوره الايـمـبـد او الـرسـالـه', 

           type: ApplicationCommandOptionType.Attachment,

            required: false, 

           }, 
        
        {

           name:'color', 

           description:'لـون الأيـمـبـد بـالـhex code', 

           type: ApplicationCommandOptionType.String,

            required: false,

           }, 
       {

           name:'message', 

           description:'رسـالـه خـارج الأيـمـبـد', 

           type: ApplicationCommandOptionType.String,

            required: false,

           },  
      {
            name: 'photo1',
            description: 'صـوره 1',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo2',
            description: 'صـوره 2',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo3',
            description: 'صـوره 3',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo4',
            description: 'صـوره 4',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo5',
            description: 'صـوره 5',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo6',
            description: 'صـوره 6',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo7',
            description: 'صـوره 7',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo8',
            description: 'صـوره 8',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo9',
            description: 'صـوره 9',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },  
        
    ]
        }, 
    
{ 


    name: 'active',

    description: 'لـتـفـعـيـل مـتـجـر',

    dm_permission: false,


    options:[

    
{

  name: 'proof',

  description: 'دلـيـل الـتـحـويـل',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

},
    

    {

      name: 'shop',

      description: 'الـمـتـجـر',

      type: ApplicationCommandOptionType.Channel,

      required: false,

      //choices: choices()

    }, 
        
        ] 
        }, 
    {
    name: 'disable',
    description:'لـتـعـطـيـل مـتـجـر مـعـيـن',
    dm_permission: false,
    options: [
      {
        name: 'shop',
        description: 'االـروم',
        type: ApplicationCommandOptionType.Channel,
        required: true,
      },
      {
        name: 'reason',
        description: 'الـسـبـب',
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  }, 
    
    {

    name: 'add-type',

    description:'لأضـافـه نـوع مـتـاجـر',

    dm_permission: false,

    admin: true,

    options: [
  {

        name: 'name',

        description:'اسـم الـنـوع',

        type: ApplicationCommandOptionType.String,

        required: true,

      },   
    {

        name: 'category',

        description: 'كـاتـاجـوري الـنـوع',

        type: ApplicationCommandOptionType.Channel,

        required: true,

      }, 
  
   {

      name: 'role',

      description:  'رتـبـه هـذا الـنـوع',

      type: ApplicationCommandOptionType.Role,

      required: true,

    }  , 
  {

      name: 'everyone',

      description:  'عـدد مـنـشـنـات افـري ون لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  , 
        {

      name: 'here',

      description:  'عـدد مـنـشـنـات هـيـر  لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  , 
        {

      name: 'shop',

      description:  'عـدد مـنـشـنـات الـمـتـجـر  لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  
    ] 
        }, 
    
{

    name: 'set-type',

    description:'لـلـتـعـديـل عـلـي نـوع مـتـاجـر',

    dm_permission: false,

    admin: true,

    options: [
  {

      name: 'type',

      description: 'الـنـوع',

      type: ApplicationCommandOptionType.String,

      required: true,

      choices: chsd
          

    }, 


{

        name: 'name',

        description:'اسـم الـنـوع الـجـديـد',

        type: ApplicationCommandOptionType.String,

        required: false,

      },   
    {

        name: 'category',

        description: 'الـكـاتـاغـوري الـجـديـد لـهـذا الـنـوع',

        type: ApplicationCommandOptionType.Channel,

        required: false,

      }, 
  
   {

      name: 'role',

      description:  'الـرتـبـه الـجـديـده لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Role,

      required: false,

    }  , 
  {

      name: 'everyone',

      description:  'عـدد مـنـشـنـات افـري ون الـجـديـده',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  , 
        {

      name: 'here',

      description:  'عـدد مـنـشـنـات هـيـر  الـجـديـده',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  , 
        {

      name: 'shop',

      description:  'عـدد مـنـشـنـات الـمـتـجـر  الـجـديـد',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  
    ] 
}, 
    {

    name: 'send-panel',

    description:'لإرسـال بـنـل الـتـقـديـم',

    dm_permission: false,

    admin: true,

    options: [
{
            name: 'panel-type',
            description:'نـوع الـتـقـديـم', 
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'تـقـديـم الإداره',
                    value:'staff'
                },
                {
                    name:'تـقـديـم الـوسـيـط',
                    value:'mediator'
                 
                }
            ]
        },
        {

      name: 'channel',

      description:  'الـروم',

      type: ApplicationCommandOptionType.Channel,

      required: false, 

    }  
        ]
       }, 
    {

    name: 'change-status',

    description:'لـلـتـعـديـل عـلـي حـالـه  تـقـديـم',

    dm_permission: false,

    admin: true,

    options: [

{

            name: 'panel-type',

            description:'نـوع الـتـقـديـم', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'تـقـديـم الإداره',

                    value:'staff'

                },

                {

                    name:'تـقـديـم الـوسـيـط',

                    value:'mediator'

                 

                }

            ]

        }, 
     {

            name: 'status',

            description:'حـالـه الـتـقـديـم الـجـديـده', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'إغـلاق الـتـقـديـم',

                    value:'close'

                },

                {

                    name:'فـتـح الـتـقـديـم',

                    value:'open'

                 

                }

            ]

        }, 
        ]
       }, 
   
    {

    name: 'reset',

    description:'لـتـرسـيـت الـمـقـدمـيـن',

    dm_permission: false,

    admin: true,

    options: [

{

            name: 'panel-type',

            description:'نـوع الـتـقـديـم', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'تـقـديـم الإداره',

                    value:'staff'

                },

                {

                    name:'تـقـديـم الـوسـيـط',

                    value:'mediator'

                 

                }

            ]

        }
        ]
        }, 
    {
        
    name:"message",
        description:'إرسـال رسـالـه لـشـخـص', 
      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
       {

            name: 'message',

            description:'الـرسـالـه', 

            type: ApplicationCommandOptionType.String,

            required: true,

}, 
        
        ]

        
        }, 
    {

        

    name:"temp-role",

        description:'إعـطـاء رتـبـه خـاصـه', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        {

            name: 'role',

            description: 
            'الـرتـبـه', 

            type: ApplicationCommandOptionType.Role,

            required: true,

}, 
        {

            name: 'time',

            description:'وقـت الـرتـبـه', 

            type: ApplicationCommandOptionType.String,

            required: true,

}, 
        
        ]
       }, 
   {

        

    name:"show-temps",

        description:'لـرؤيـه الـرتـب الـمـؤقـتـه لـعـضـو', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        ]
        }, 
    
   {

        

    name:"remove-temp",

        description:'لإزالـه رتـبـه مـؤقـتـه لـعـضـو', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        {

            name: 'role',

            description:'الـرتـبـه', 

            type: ApplicationCommandOptionType.Role,

            required: true,

}, 
        ]
        }
    
    
]; 
    client.application.commands.set(commands).then(() => {

        console.log('All commands registered');

    }).catch(err => {

        console.error('Error registering commands:', err);

    });

}
async function updateTypesAndCommands(typesData) {

    client.types = typesData;

    

    const choices = client.types.map(t => ({ name: t.name, value: t.id }));

   const commands = [
    {
      name: 'shop-setup',
      description: 'ارسال تكت الشراء .',
      dm_permission: false,
      default_member_permissions: 8,
    },
    {
      name: 'mentions',
      description: 'عـرض مـنـشـنـات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
    {
      name: 'r-mentions',
      description: 'اعادة تـعـيـيـن مـنـشـنـات المـتـاجـر ',
      dm_permission: false,
      default_member_permissions: 8,
        
        options:[
            {
          name: 'channel',
      description: 'الروم التي تريد ارسال فيها الاشعار',
      type: ApplicationCommandOptionType.Channel,
      required: false,
     channel_types: [ChannelType.GuildText]

            },
              {
                  name: `image`,
                  description: `صورة الأميبد`,
                  type: ApplicationCommandOptionType.String,
                  required: false,
              },
        ]
    },
    {
      name: 'shop-data',
      description: 'عـرض مـعـلـومـات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
        {
      name: 'warns',
      description: 'عـرض تـحـذيـرات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
    {
    name: 'owner',
    description: 'change owner of a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    {
      name: 'new-owner',
      description: 'صـاحـب المـتـجـر الجـديـد',
      type: ApplicationCommandOptionType.User,
      required: true,
    }, 
        {

                  name: `image`,

                  description: `صورة الأميبد`,

                  type: ApplicationCommandOptionType.String,

                  required: false,

              },
    ]
    },
    {
    name: 'warn',
    description: 'warn a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    
        {

      name: 'reason',

      description:'السبب',

      type: ApplicationCommandOptionType.String,

      required: true,

      

    },
        {

  name: 'proof',

  description: 'دلـيـل الـمـخـالـفـه',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
    ]
    },
    {
    name: 'unwarn',
    description: 'unwarn a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    {
      name: 'amount',
      description: 'عـدد التـحـذيـرات',
      type: ApplicationCommandOptionType.Number,
      required: true,
    },
        
{

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}        
    ]
    },
    {
      name: 'add-helper',
      description: ' اضـافـة مساعد للمـتـجـر ',
      dm_permission: false,
      options: [
        {
          name: `helper`,
          description: `المـساعد.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
         }, 
          {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
      ]
    },
    {
      name: 'remove-helper',
      description: ' ازالة مساعد مـن مـتـجـر مـعـيـن ',
      dm_permission: false,
      options: [
        {
          name: `helper`,
          description: `المساعد.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
         }
      ]
    }, 
    { 
    name: 'shop',
    description: 'create a shop',
    dm_permission: false,
    options: [
    {
      name: 'type',
      description: 'نوع المتجر',
      type: ApplicationCommandOptionType.String,
      required: true,
      choices: choices 
    },
    {
      name: 'name',
      description: 'اسم المتجر',
      type: ApplicationCommandOptionType.String,
      required: true,
     // choices: choices()
    },
    {
      name: 'owner',

      description: 'مالك المتجر',
      type: ApplicationCommandOptionType.User,
      required: true,
      //choices: choices()
    }, 
        {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
    ]
    }, 

  
    
     
   
  
    { 

    name: 'delete-shop',

    description: 'لـحـذف مـتـجـر',

    dm_permission: false,


    options:[
        {

        name: 'shop',

        description: 'الـمـتـجـر',

        type: ApplicationCommandOptionType.Channel,

        required: true,

      }, 
        {

        name: 'reason',

        description: 'الـسـبـب',

        type: ApplicationCommandOptionType.String,

        required: true,

      }, 
        {

  name: 'proof',

  description: 'دلـيـل الـمـخـالـفـه',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

},
        
        ] 
        },
    
    {
         
    name: 'add-mentions',

    description: 'إضـافـه مـنـشـنـات لـمـتـجـر',

    dm_permission: false,


    options:[
    
    {

      name: 'shop',

      description: 'الـمـتـجـر',

      type: ApplicationCommandOptionType.Channel,

      required: true,

      //choices: choices()

    }, 
   {

      name: 'everyone',

      description: 'عـدد مـنـشـنـات everyone',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
{

      name: 'here',

      description: 'عـدد مـنـشـنـات here',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
        {

      name: 'shop_mentions',

      description: 'عـدد مـنـشـنـات الـمـتـجـر',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
        {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
        
] 
}, 
    {

         

    name: 'create-request',

    description: 'إنـشـاء طـلـب',

    dm_permission: false,


    options:[

    {

  name: 'owner',

  description: 'صـاحـب الـطـلـب',

  type: ApplicationCommandOptionType.User,

  required: true,

}, 
        {

  name: 'order',

  description:'الـطـلـب',

  type: ApplicationCommandOptionType.String,

  required: true,

}, 
        {

  name: 'time',

  description: 'الـمـده بـالأيـام',

  type: ApplicationCommandOptionType.Number,

  required: true,

}, 
        
        {
  name: 'mention',
  description: 'الـمـنـشـن',
  type: ApplicationCommandOptionType.String,
  required: true,
  choices: [
    {
      name: 'مـنـشـن هـيـر',
      value: 'here'
    },
    {
      name: 'مـنـشـن أفـري',
      value: 'everyone'
    }
  ]
}, 
        {

  name: 'proof',

  description: 'دلـيـل الـتـحـويـل',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}, 
        
        

                
{

  name: 'photo',

  description: 'صـوره',

  type: ApplicationCommandOptionType.Attachment,

  required: false,

}, 
        
        
        
        
        ]
        }, 
    {
    name: 'create-auction',
    description: 'إنـشـاء مـزاد',
    dm_permission: false,
    options: [
        {
            name: 'owner',
            description: 'صـاحـب الـمـزاد',
            type: ApplicationCommandOptionType.User,
            required: true,
        },
        {
            name: 'item',
            description:'الـسـلـعـه',
            type: ApplicationCommandOptionType.String,
            required: true,
        },
        {

            name: 'price',

            description:'الـسـعـر الـبـدائـي',

            type: ApplicationCommandOptionType.String,

            required: true,

        },
        {
            name: 'time',
            description: 'الـمـده بـالـدقـائـق',
            type: ApplicationCommandOptionType.String, 
            required: true,
        },
        {
            name: 'mention',
            description: 'الـمـنـشـن',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'مـنـشـن هـيـر',
                    value: 'here'
                },
                {
                    name: 'مـنـشـن أفـري',
                    value: 'everyone'
                }
            ]
        },
        {

            name: 'tax',

            description: 'الـسـعـر بـالـضـريـبـة؟ ',

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'لا',

                    value: 'لا'

                },

                {

                    name: 'نـعـم',

                    value: 'نـعـم'

                }

            ]

        },
        {
            name: 'channel',
            description: 'روم الـمزاد', 
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'مـزاد 1',
                    value: config.auction 
                },
                {
                    name:'مـزاد 2',
                    value: config.auction2
                }
            ]
        },
        {
            name: 'proof',
            description: 'دلـيـل الـتـحـويـل',
            type: ApplicationCommandOptionType.Attachment,
            required: true,
        },
        {
            name: 'photo1',
            description: 'صـوره 1',
            type: ApplicationCommandOptionType.Attachment,
            required: true,
        },
        {
            name: 'photo2',
            description: 'صـوره 2',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo3',
            description: 'صـوره 3',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo4',
            description: 'صـوره 4',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo5',
            description: 'صـوره 5',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo6',
            description: 'صـوره 6',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo7',
            description: 'صـوره 7',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo8',
            description: 'صـوره 8',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo9',
            description: 'صـوره 9',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
    ]
}, 
    {

         

    name: 'say',

    description: 'إرسـال رسـالـه',

    dm_permission: false,


    options:[

        {

            name: 'embed',

            description: 'الـرسـالـه أيـمـبـد؟ ',

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'لا',

                  value:'false'

                },

                {

                    name: 'نـعـم',

                    value:'true'

                }

            ]

        },
        
       {
           name:'content', 
           description:'مـحـتـوي الـرسـالـه او وصـف الأيـمـبـد', 
           type: ApplicationCommandOptionType.String,

            required: true,
           }, 
        {

           name:'title', 

           description:'عـنـوان الأيـمـبـد', 

           type: ApplicationCommandOptionType.String,

            required: false,

           }, 
        {

           name:'image', 

           description:'صـوره الايـمـبـد او الـرسـالـه', 

           type: ApplicationCommandOptionType.Attachment,

            required: false, 

           }, 
        
        {

           name:'color', 

           description:'لـون الأيـمـبـد بـالـhex code', 

           type: ApplicationCommandOptionType.String,

            required: false,

           }, 
      {

           name:'message', 

           description:'رسـالـه خـارج الأيـمـبـد', 

           type: ApplicationCommandOptionType.String,

            required: false,

           },   
        
        {
            name: 'photo1',
            description: 'صـوره 1',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo2',
            description: 'صـوره 2',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo3',
            description: 'صـوره 3',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo4',
            description: 'صـوره 4',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo5',
            description: 'صـوره 5',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo6',
            description: 'صـوره 6',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo7',
            description: 'صـوره 7',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo8',
            description: 'صـوره 8',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo9',
            description: 'صـوره 9',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        
    ]
        }, 
    
{ 


    name: 'active',

    description: 'لـتـفـعـيـل مـتـجـر',

    dm_permission: false,


    options:[

    
{

  name: 'proof',

  description: 'دلـيـل الـتـحـويـل',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

},
    

    {

      name: 'shop',

      description: 'الـمـتـجـر',

      type: ApplicationCommandOptionType.Channel,

      required: false,

      //choices: choices()

    }, 
        
        ] 
        }, 
    {
    name: 'disable',
    description:'لـتـعـطـيـل مـتـجـر مـعـيـن',
    dm_permission: false,
    options: [
      {
        name: 'shop',
        description: 'االـروم',
        type: ApplicationCommandOptionType.Channel,
        required: true,
      },
      {
        name: 'reason',
        description: 'الـسـبـب',
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  }, 
    
    {

    name: 'add-type',

    description:'لأضـافـه نـوع مـتـاجـر',

    dm_permission: false,

    admin: true,

    options: [
  {

        name: 'name',

        description:'اسـم الـنـوع',

        type: ApplicationCommandOptionType.String,

        required: true,

      },   
    {

        name: 'category',

        description: 'كـاتـاجـوري الـنـوع',

        type: ApplicationCommandOptionType.Channel,

        required: true,

      }, 
  
   {

      name: 'role',

      description:  'رتـبـه هـذا الـنـوع',

      type: ApplicationCommandOptionType.Role,

      required: true,

    }  , 
  {

      name: 'everyone',

      description:  'عـدد مـنـشـنـات افـري ون لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  , 
        {

      name: 'here',

      description:  'عـدد مـنـشـنـات هـيـر  لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  , 
        {

      name: 'shop',

      description:  'عـدد مـنـشـنـات الـمـتـجـر  لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  
    ] 
        }, 
    
{

    name: 'set-type',

    description:'لـلـتـعـديـل عـلـي نـوع مـتـاجـر',

    dm_permission: false,

    admin: true,

    options: [
  {

      name: 'type',

      description: 'الـنـوع',

      type: ApplicationCommandOptionType.String,

      required: true,

      choices: choices 
          

    }, 


{

        name: 'name',

        description:'اسـم الـنـوع الـجـديـد',

        type: ApplicationCommandOptionType.String,

        required: false,

      },   
    {

        name: 'category',

        description: 'الـكـاتـاغـوري الـجـديـد لـهـذا الـنـوع',

        type: ApplicationCommandOptionType.Channel,

        required: false,

      }, 
  
   {

      name: 'role',

      description:  'الـرتـبـه الـجـديـده لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Role,

      required: false,

    }  , 
  {

      name: 'everyone',

      description:  'عـدد مـنـشـنـات افـري ون الـجـديـده',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  , 
        {

      name: 'here',

      description:  'عـدد مـنـشـنـات هـيـر  الـجـديـده',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  , 
        {

      name: 'shop',

      description:  'عـدد مـنـشـنـات الـمـتـجـر  الـجـديـد',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  
    ] 
}, 
    {

    name: 'send-panel',

    description:'لإرسـال بـنـل الـتـقـديـم',

    dm_permission: false,

    admin: true,

    options: [
{
            name: 'panel-type',
            description:'نـوع الـتـقـديـم', 
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'تـقـديـم الإداره',
                    value:'staff'
                },
                {
                    name:'تـقـديـم الـوسـيـط',
                    value:'mediator'
                 
                }
            ]
        },
        {

      name: 'channel',

      description:  'الـروم',

      type: ApplicationCommandOptionType.Channel,

      required: false, 

    }  
        ]
       }, 
    {

    name: 'change-status',

    description:'لـلـتـعـديـل عـلـي حـالـه  تـقـديـم',

    dm_permission: false,

    admin: true,

    options: [

{

            name: 'panel-type',

            description:'نـوع الـتـقـديـم', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'تـقـديـم الإداره',

                    value:'staff'

                },

                {

                    name:'تـقـديـم الـوسـيـط',

                    value:'mediator'

                 

                }

            ]

        }, 
     {

            name: 'status',

            description:'حـالـه الـتـقـديـم الـجـديـده', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'إغـلاق الـتـقـديـم',

                    value:'close'

                },

                {

                    name:'فـتـح الـتـقـديـم',

                    value:'open'

                 

                }

            ]

        }, 
        ]
       }, 
       
    {

    name: 'reset',

    description:'لـتـرسـيـت الـمـقـدمـيـن',

    dm_permission: false,

    admin: true,

    options: [

{

            name: 'panel-type',

            description:'نـوع الـتـقـديـم', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'تـقـديـم الإداره',

                    value:'staff'

                },

                {

                    name:'تـقـديـم الـوسـيـط',

                    value:'mediator'

                 

                }

            ]

        }
        ]
        }, 
      {
        
    name:"message",
        description:'إرسـال رسـالـه لـشـخـص', 
      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
       {

            name: 'message',

            description:'الـرسـالـه', 

            type: ApplicationCommandOptionType.String,

            required: true,

}, 
        
        ]

        
        }, 
       
    {

        

    name:"temp-role",

        description:'إعـطـاء رتـبـه خـاصـه', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        {

            name: 'role',

            description: 
            'الـرتـبـه', 

            type: ApplicationCommandOptionType.Role,

            required: true,

}, 
        {

            name: 'time',

            description:'وقـت الـرتـبـه', 

            type: ApplicationCommandOptionType.String,

            required: true,

}, 
        
        ]
       }, 
       
    {

        

    name:"show-temps",

        description:'لـرؤيـه الـرتـب الـمـؤقـتـه لـعـضـو', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        ]
        }, 
       {

        

    name:"remove-temp",

        description:'لإزالـه رتـبـه مـؤقـتـه لـعـضـو', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        {

            name: 'role',

            description:'الـرتـبـه', 

            type: ApplicationCommandOptionType.Role,

            required: true,

}, 
        ]
        }
    
       
]; 

       client.application.commands.set(commands).then(() => {

        console.log('All commands registered');

    }).catch(err => {

        console.error('Error registering commands:', err);

    });

}
async function send(ids,embed)  {
    
  for (const id of ids){
    let user = await client2.users.fetch(id)
    
    await user.send({embeds:[embed]})  
   
      
      
      
      } 
    
    
    
    } 
client.on('messageCreate', async m => {
  if (!m.guild) return;
  if (m.author.bot) return;

  let data = await db.get(`shop_${m.channel.id}`);
  if (data) {
    let shouldSendLine = false;

    if (m.content.includes('@everyone') || m.content.includes('@here')) {
      if (m.content.includes('@everyone') && data.every <= 0) {
        m.reply(`**تم قفل المتجر**`);
        await m.channel.permissionOverwrites.edit(m.guild.roles.everyone, {
          ViewChannel: false,
        });
          await db.set(`shop_${m.channel.id}.status`,'0')
      } else if (m.content.includes('@here') && data.here <= 0) {
        m.reply(`**تم قفل المتجر**`);
        await m.channel.permissionOverwrites.edit(m.guild.roles.everyone, {
          ViewChannel: false,
        });
          await db.set(`shop_${m.channel.id}.status`,'0')
      } else {
        if (m.content.includes('@everyone')) {
          data.every -= 1;
        }
        if (m.content.includes('@here')) {
          data.here -= 1;
        }
        shouldSendLine = true;
      }
    }

    if (m.content.includes(config.role)) {
      if (data.shop <= 0) {
        m.reply(`**تم قفل المتجر**`);
        await m.channel.permissionOverwrites.edit(m.guild.roles.everyone, {
          ViewChannel: false,
        });
          await db.set(`shop_${m.channel.id}.status`,'0')
          
      } else {
        data.shop -= 1;
        shouldSendLine = true;
      }
    }

    await db.set(`shop_${m.channel.id}`, data);

    if (shouldSendLine) {
      m.channel.send({ files: [config.line] });
    }
  }
});
client.on("interactionCreate", async (i) =>  {
   
    let interaction = i
    if (i.isChatInputCommand()) {
    switch (i.commandName) {
        
     case "remove-temp": {
    let role = await i.options.getRole('role');
    let user = await i.options.getUser('user');
    await i.deferReply({ ephemeral: false });

    if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        await i.editReply("**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**");
        return;
    }

    let data = await db.get(`roleData_${user.id}`);

    if (!data || data.length === 0) {
        await i.editReply('**هـذا الـعـضـو لا يـمـتـلـك أي رتـب مـؤقـتـه**');
        return;
    }

    if (!data.some(rol => rol.id === role.id)) {
        await i.editReply('**هـذه الـرتـبـه لـيـسـت رتـبـه مـؤقـتـه يـرجـي إسـتـخـدام أمر `/show-temps`لـرؤيـه الـرتـب الـمـؤقـتـه لـلـعـضـو**');
        return;
    }

    let romm = i.guild.roles.cache.get(role.id);
    let bot = i.guild.members.cache.get(client.user.id);

    if (bot.roles.highest.position <= romm.position) {
        await i.editReply('**يـرجـي إعـطـائـي الـصـلاحـيـات الـكـافـيـه لازالـه الـرتـبـه**');
        return;
    }

    let nazi = i.guild.members.cache.get(user.id);
    await nazi.roles.remove(role.id);

    let niggers = data.filter(dataa => dataa.id !== role.id);
    await db.set(`roleData_${user.id}`, niggers);

    await i.editReply('**تـم إزالـه الـرتـبـه بـنـجـاح**');
         
      let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']   
         const embeddlog = {

      title: `تـم إزالـه رتـبـه`,

      description: `الـمـسـؤول : <@${i.user.id}> `,

      fields: [

   {

          name: 'الـرتـبـه',

          value: `${role}`,

          inline: true

        },

          

          {

          name: 'الـعـضـو',

          value: `<@${user.id}>`,

          inline: true

        }, 

        



        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },

 timestamp: new Date(),

    };
  await  send(ids, embeddlog) 
} break;              
     case "show-temps": {
    await i.deferReply({ ephemeral: false });

    if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        await i.editReply("**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**");
        return;
    }

    let ussr = i.options.getUser('user');
    let data = await db.get(`roleData_${ussr.id}`);

    if (!data || data.length === 0) {
        await i.editReply('**هـذا الـعـضـو لا يـمـتـلـك أي رتـب مـؤقـتـه**');
        return;
    }

    let roles = '';
    for (const role of data) {
        roles += `**<@&${role.id}> - <t:${Math.floor(role.timestamp / 1000)}:R> by <@${role.author}>**\n`;
    }

    let embed = new EmbedBuilder()
        .setTitle(`الـرتـب الـمـؤقـتـه الـخـاصـه بـ ${ussr.username}`)
        .setDescription(roles)
        .setFooter({ text: `${i.guild.name}`, iconURL: i.guild.iconURL() })
        .setAuthor({ name: i.guild.name, iconURL: i.guild.iconURL() });

    await i.editReply({ embeds: [embed], content: `${i.user}` });
} break;
     case 'temp-role': {
            await i.deferReply({ ephemeral: false });

            if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                await i.editReply("**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**");
                return;
            }

            let ussr = i.options.getUser('user');
            let role = i.options.getRole('role');
            let time = i.options.getString('time');

            let duration = 0;

            if (time.endsWith('s')) {
                duration = parseFloat(time) * 1000;
            } else if (time.endsWith('mi')) {
                duration = parseFloat(time) * 60000;
            } else if (time.endsWith('h')) {
                duration = parseFloat(time) * 3600000;
            } else if (time.endsWith('d')) {
                duration = parseFloat(time) * 86400000;
            } else if (time.endsWith('w')) {
                duration = parseFloat(time) * 604800000;
            } else if (time.endsWith('m')) {
                duration = parseFloat(time) * 2592000000;
            } else {
                await i.editReply("**يـرجـي كـتـابـه رقـم يـنـتـهـي بـ s , mi , h , d , w , m**");
                return;
            }

            const timestamp = Date.now() + duration;

            if (timestamp <= Date.now()) {
                await i.editReply("**يـرجـي كـتـابـه مـده صـحـيـحـه**");
                return;
            }

            const roleDataKey = `roleData_${ussr.id}`;
            const roleData = await db.get(roleDataKey) || [];

            if (roleData.some(d => d.id === role.id)) {
                await i.editReply(`**هـذا الـعـضـو يـمـتـلـك هـذه الـرتـبـه بـالـفـعـل سـتـزال بـعـد <t:${Math.floor(roleData.find(d => d.id === role.id).timestamp / 1000)}:R>**`);
                return;
            }

            let bot = i.guild.members.cache.get(client.user.id);
            let rolee = i.guild.roles.cache.get(role.id);

            if (rolee.position >= bot.roles.highest.position) {
                await i.editReply('**لا يـمـكـنـنـي إعـطـائـه هـذا الـرتـبـه**');
                return;
            }

            let member = i.guild.members.cache.get(ussr.id);
            await member.roles.add(role);
            await i.editReply(`**تـم إعـطـائـه الـرتـبـه بـنـجـاح سـتـزال خـلال   <t:${Math.floor(timestamp / 1000)}:R> **`);

            roleData.push({
                timestamp,
                time: duration,
                id: role.id,
                user: ussr.id,
                guild: i.guild.id, 
                author: i.user.id
            });
            await db.set(roleDataKey, roleData);
let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']   
         const embeddlog = {

      title: `تـم إعـطـاء رتـبـه`,

      description: `الـمـسـؤول : <@${i.user.id}> `,

      fields: [

   {

          name: 'الـرتـبـه',

          value: `${role}`,

          inline: true

        },

          

          {

          name: 'الـعـضـو',

          value: `<@${ussr.id}>`,

          inline: true

        }, 

        {
    name:'الـمـده',
            value: `<t:${Math.floor(timestamp / 1000)}:R>`, 
            inline: true, 
            
            
            } 



        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },

 timestamp: new Date(),

    };
  await  send(ids, embeddlog) 
            break;
        } break;
     case "message"  :  {
      await i.deferReply({ephemeral: true}) 
      let user = await  i.options.getUser('user')
      let message = await i.options.getString('message') 
   if (i.user.id  !=  '1205548791525154867')  {
   return i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**');
       
       
       } else  {
  let Ussr = await client.users.fetch(user.id)
 
    
          Ussr.send({
                content: message
            }).then(() => {
                i.editReply('**تـم إرسـال الـرسـالـة  بـنـجـاح**');
                
            }).catch(() => {
                i.editReply('**لا يـمـكـنـنـي إرسـال رسـالـه لـهـذا الـعـضـو**');
            });
           
           
         }
      
      } break; 
     case "reset":{
       await  i.deferReply({ephemeral:true})

    const khra =['1205548791525154867','1133166513348694106','464517647497691150','1174351872186912908']

if (!khra.includes(i.user.id))  {

i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**') 

return; 

}
let sta   
         let type = i.options.get('panel-type').value 
         if (type ==='staff'){
   sta ='الإداره'        
             await  db.delete('staff_app');
             
             } 
    
       if (type ==='mediator'){
sta ='الـوسـطـاء'
             await  db.delete('mediator_app');

             

             }
       
     await i.editReply(`**تـم تـرسـيـت مـقـدميـن تـقـديـم ${sta} بـنـجـاح**`)  
       } break; 
     case "change-status":{
         
    await  i.deferReply({ephemeral:true})

    const khra =['1205548791525154867','1133166513348694106','464517647497691150']

if (!khra.includes(i.user.id))  {

i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**') 

return; 

}
         let type = i.options.get('panel-type').value 
         let status = i.options.get('status').value 
  let op; 
         if (type  ===  'staff'){
     op = 'الإداره'
             
             
             
             }
         if (type ==='mediator')  {
    op ='الـوسـطـاء'         
             
             } 
   let data = await db.get(type) || 'open'  
   if (status ==='open')   {
       
    if (data ==='open'){
    await i.editReply(`**تقـديـم ${op} مـفـتـوح بـالـفـعـل**`)
        return;
        
        } else  {
   await db.set(type,'open')
            await  i.editReply(`**تـم  فـتـح تـقـديـم ${op} بـنـجـاح**`) 
            
            
            
      
       }
       
       
      
      
      }
   if (status ==='close'){
       
       if (data ==='close')  {
           
   await i.editReply(`**تـقـديـم  ${op} مـغـلـق بـالـفـعـل**`)
           return;
           } else {
   await db.set(type,'close')
               await i.editReply(`**تـم إغـلاق تـقـديـم ${op} بـنـجـاح**`)
               
               
               } 
       
       } 
         } break; 
     case "send-panel"  :  {
    await  i.deferReply({ephemeral:true})
    const khra =['1205548791525154867','1133166513348694106','464517647497691150','1174351872186912908']
if (!khra.includes(i.user.id))  {

i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**') 
return; 
}
    
    let channel = i.options.getChannel('channel')  ||  i.channel 
    let type = i.options.get('panel-type').value 
    let embed; 
    let row = new ActionRowBuilder(); 
    
    if (type ==='staff'){
 embed = new EmbedBuilder()
        .setDescription('تـقـديـم إداره')
        .setTitle('تـقـديـم إداره');
row.addComponents( new ButtonBuilder()
                  .setCustomId('admin')

                        .setLabel('تـقـديـم إداره')

                        .setStyle(ButtonStyle.Secondary) 
                  
                  );
    
    }
    
    
   if (type ===  'mediator'){
       
       embed = new EmbedBuilder()

        .setDescription('تـقـديـم وسـطـاء')

        .setTitle('تـقـديـم وسـطـاء');

row.addComponents( new ButtonBuilder()

                  .setCustomId('mediator')

                        .setLabel('تـقـديـم وسـطـاء')

                        .setStyle(ButtonStyle.Secondary) 

                  

                  );
       
       }
    embed.setThumbnail(i.guild.iconURL()) 

           

            .setFooter({ text: `${i.guild.name}`, iconURL: i.guild.iconURL() }) 

            .setAuthor({ name: i.guild.name, iconURL: i.guild.iconURL() });
    await  channel.send({embeds:[embed], components:[row]})
    await i.editReply('**تـم إرسـال بـنـل الـتـقـديـم بـنـجـاح**')
                       let mnk = await db.get(type)
                       if (!mnk)  {
     await db.set(type,'open')                     
                           
                           } 
    } break; 
     case "set-type": {
    await i.deferReply();
    const filePath = path.join(__dirname, 'types.js');
    if (types.length === 0) {
        await i.editReply('** يـجـب إضـافـه أنـواع مـتـاجـر أولا **');
        return;
    }
const khra =['1205548791525154867','1133166513348694106']
if (!khra.includes(i.user.id))  {

i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**') 
return; 
}
    let typeu = i.options.get('type').value;
    const type = types.find(x => x.id === typeu);
    const everyone = i.options.getNumber('everyone') || type.every;
    const here = i.options.getNumber('here') || type.here;
    const shop = i.options.getNumber('shop') || type.shop;
    
    const category = i.options.getChannel('category') || type.id;
    const role = i.options.getRole('role') || type.role;
    const name = i.options.getString('name') || type.name;
    
    const chann = i.guild.channels.cache.get(category.id || category);
    if (!chann) {
        await i.editReply('**لـم أسـتـطـع الـعـثـور عـلـي هـذا الـكـاتـاغـوري**');
        return;
    }

    if (chann.type !== ChannelType.GuildCategory) {
        await i.editReply('** ضـع كـاتـاغـوري صـالـح**');
        return;
    }
    
    fs.readFile(filePath, 'utf8', async (err, data) => {
        if (err) {
            console.error('Error reading the file:', err);
            return;
        }

        const typesMatch = data.match(/const types = (\[\s*[\s\S]*\s*\]);/);
        if (!typesMatch) {
            console.error('Could not find the types array in the file');
            return;
        }

        let types = JSON.parse(typesMatch[1]);
    
        const idToUpdate = type.id;
        
        const newObject = {
            "id": category.id || category,
            "name": name,
            "role": role.id || role,
            "every": everyone,
            "here": here,
            "shop": shop
          
        };

        types = types.map(type => type.id === idToUpdate ? newObject : type);
        updateCommands();

        const newFileContent = data.replace(typesMatch[1], JSON.stringify(types, null, 4));

        fs.writeFile(filePath, newFileContent, 'utf8', async (err) => {
            if (err) {
                console.error('Error writing to the file:', err);
                return;
            }

            const ppp = i.options.getRole('role');
            if (ppp) {
                const channells = i.guild.channels.cache.filter(channel => channel.parentId === category.id || channel.parentId === category);

                for (const channel of channells.values()) {
                    const data = await db.get(`shop_${channel.id}`);
                    if (data) {
                        const owner = i.guild.members.cache.get(data.owner);
                        
                        await db.set(`shop_${channel.id}.type`, ppp.id);
                        
                        
                            const rt = i.guild.roles.cache.get(ppp.id);
                            const rtb = i.guild.roles.cache.get(type.role);
                            if (rt) {
                                await owner.roles.remove(rtb);
                                await owner.roles.add(rt);
                            
                        }
                    }
                }
            }

            const pp = i.options.getChannel('category');
            if (pp) {
                const channels = i.guild.channels.cache.filter(channel => channel.parentId === category.id || channel.parentId === type.id);
                for (const channel of channels.values()) {
                    const data = await db.get(`shop_${channel.id}`);
                    if (data) {
                        await channel.setParent(category.id || category);
                    }
                }
            }
            console.log('File updated successfully');
            await i.editReply(`** تـم تـغـيـيـر بـيـانـات نـوع ${name} بـنـجـاح**`);
        });
    });
} break;
     case 'add-type': {
    await interaction.deferReply({ ephemeral: false, content: '**loading...**' });

    const everyone = interaction.options.getNumber('everyone');
    const here = interaction.options.getNumber('here');
    const shop = interaction.options.getNumber('shop');
    
    const category = interaction.options.getChannel('category');
    const role = interaction.options.getRole('role');
    const name = interaction.options.getString('name');

    const chann = interaction.guild.channels.cache.get(category.id);
    const { member, guild } = interaction;
const khra =['1205548791525154867','1133166513348694106']
if (!khra.includes(i.user.id))  {

i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**') 
return; 
}
   
    if (!chann) {
        await interaction.editReply('**لـم أسـتـطـع الـعـثـور عـلـي هـذا الـكـاتـاغـوري**');
        return;
    }
if (chann.type !== ChannelType.GuildCategory)  {
i.editReply('** ضـع كـاتـاغـوري صـالـح**')
    return; 

} 
   
    const newType = {
        id: category.id,
        name: name,
        role: role.id,
        every: everyone,
        here: here,
        shop: shop
    
    };

    fs.readFile(typesPath, 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading types.js:', err);
            return;
        }

        let typesData = require('./types.js');
        try {
            
        } catch (e) {
            console.error('Error parsing types.js:', e);
        }

        typesData.push(newType);

        fs.writeFile(typesPath, `const types = ${JSON.stringify(typesData, null, 4)};\nmodule.exports = types;`, 'utf8', (err) => {
            if (err) {
                console.error('Error writing to types.js:', err);
                return;
            }

            console.log('Successfully added new type!');
            interaction.editReply(`**تـم إضـافـه نـوع ${name} بـنـجـاح**`);

            updateTypesAndCommands(typesData); // تحديث الأنواع والأوامر بعد إضافة نوع جديد
        });
    });

   } break;
     case "disable":{
 
       
       
          await i.deferReply({ ephemeral: true });
                const shop = i.options.getChannel('shop');
                const reason = i.options.getString('reason');

                
                const { member, guild } = i;
                
if (!member.roles.cache.has(config.admin2)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${config.admin2}>`);

        return;

    }
                const datap = await db.get(`shop_${shop.id}`);
                if (!datap) {
                    await i.editReply('**هـذا الـروم لـيـس مـتـجـر**');
                    return;
                }

                const iiff = await i.guild.channels.fetch(shop.id);
              
  
 if (datap.status === "0"){
     
  i.editReply('**هـذا الـروم مـعـطـل بـالـفـعـل**')   
    return; 
     } 
  
                    await iiff.permissionOverwrites.edit(i.guild.roles.everyone, {
                        ViewChannel: false,
                    });

                    const embedlog = {

                        title: `تـم تـعـطـيـل الـمـتـجـر`,

                        description: `الـمـسـؤول : <@${i.user.id}>`,

                        fields: [

                            {

                                name: 'الـسـبـب',

                                value: reason ,

                                inline: true,

                            },

                              

                        ],

                        footer: {

                            text: `Dev By : DEAD`,

                        },

                        timestamp: new Date(),
                        image: proof

                    };

                    i.guild.channels.fetch(shop.id)
                        .then(channel => {
                            channel.send({ content: `<@${datap.owner}>`, embeds: [embedlog] });
                        });

                    await i.editReply('**تـم تـعـطـيـل الـمـتـجـر بـنـجـاح**');
  db.set(`shop_${shop.id}.status`,"0")          
      const embeddlog = {

      title: `تـم تـعـطـيـل مـتـجـر `,

      description: `الـمـسـؤول : <@${i.user.id}> `,

      fields: [

   {

          name: 'الـمـتـجـر   ',

          value: `<#${shop.id}>`,

          inline: true

        },

          

          {

          name: 'الـسـبـب',

          value: reason,

          inline: true

        }, 

        



        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },

 timestamp: new Date(),

    };
      
          const logg = i.guild.channels.cache.get(config.commandlog)
          logg.send({embeds:[embeddlog]}); 
      let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')

await uzw.send({embeds:[embedlog]})

    let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']
    
    await  send(ids, embedlog) 

    
  
    
       
            
        
       } break; 
     case "active": {
  await i.deferReply({ ephemeral: false });

  const { member, guild } = i;

  if (!member.roles.cache.has(config.admin2)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${config.admin2}>`);

        return;

    }

  const shopi = i.options.getChannel('shop') || i.channel;
  const shopoo = await i.guild.channels.fetch(shopi.id);

  if (!shopoo) {
    await i.editReply('**لا أسـتـطـيـع الـعـثـور عـلـي هـذه الـروم**');
    return;
  }

  const shppp = await db.get(`shop_${shopi.id}`);

  if (!shppp) {
    await i.editReply('**هـذا الـروم لـيـس مـتـجر**');
    return;
  }

  if (shppp.status === "1") {
    await i.editReply('**الـروم لـيـس مـعـطـل**');
    return;
  }

  if (shppp.status === "0") {
    await shopi.permissionOverwrites.edit(i.guild.roles.everyone, {
      ViewChannel: true,
    });
let proof = i.options.getAttachment('proof')
    const embedlog = {
      title: `تـم تـفـعـيـل الـمـتـجـر`,
      description: `يـرجـي قـرائـه الـقـوانـيـن و الإلـتـزام بـهـا `,
      footer: {
        text: `Dev By : Itadori `,
      },
      timestamp: new Date(),
    };

    const uuiio = await db.get(`shop_${shopi.id}`);
    await db.set(`shop_${shopi.id}.status`, "1");

    await shopi.send({ embeds: [embedlog], content: `<@${uuiio.owner}>` });
    await i.editReply('**تـم تـفـعـيـل الـمـتـجـر بـنـجـاح**');

    const embedlogi = {
      title: `تـم تـفـعـيـل مـتـجـر`,
      description: `الـمـسـؤول : <@${i.user.id}> `,
      fields: [
        {
          name: 'الـمـتـجـر  : ',
          value: `<#${shopi.id}>`,
          inline: true,
        },
      ],
      footer: {
        text: `Dev By : itadori & ra3d`,
      },
      timestamp: new Date(),
        image: proof
    };

    const logg = i.guild.channels.cache.get(config.commandlog);
    if (logg) {
      await logg.send({ embeds: [embedlogi] });
        

    
let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, embedlogi) 


    
    }
  } else {
    await i.editReply('**حـدث خـطـأ**');
  }
} break;
     case "say"  :  {
    let message  = i.options.getString('message')
   
   const photo1 = i.options.getAttachment('photo1');

    const photo2 = i.options.getAttachment('photo2');

    const photo3 = i.options.getAttachment('photo3');

    const photo4 = i.options.getAttachment('photo4');

    const photo5 = i.options.getAttachment('photo5');

    const photo6 = i.options.getAttachment('photo6');

    const photo7 = i.options.getAttachment('photo7');

    const photo8 = i.options.getAttachment('photo8');

    const photo9 = i.options.getAttachment('photo9'); 
    
    let photos = [];

    if (photo1) photos.push(photo1);

    if (photo2) photos.push(photo2);

    if (photo3) photos.push(photo3);

    if (photo4) photos.push(photo4);

    if (photo5) photos.push(photo5);

    if (photo6) photos.push(photo6);

    if (photo7) photos.push(photo7);

    if (photo8) photos.push(photo8);

    if (photo9) photos.push(photo9);
  await i.deferReply({ephemeral:true})
    let type = i.options.get('embed').value
    let content = i.options.getString('content') 
    let title = i.options.getString('title') 
    let image = i.options.getAttachment('image')
    let color = i.options.getString('color')
    if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)){
        
await i.editReply('**أنـت لا تـمـتـلـك صـلاحـيـه لإسـتـخـدام هـذا الأمـر**')
        return; 
        } 
    
 if (type ==='false' )   {
     
    
    if (image) photos.push(image.url);
     await i.channel.send({content: content, files:photos})
     await i.editReply('**تـم إرسـال الـرسـالـه بـنـجـاح**')

     
     
     } 
if (type ==='true'){
    
    if (color)  {
   const validator = require('validator');

function isHexColor(color) {

    return validator.isHexColor(color);

}
      let test =  isHexColor(color)
  if (test === false){
      
   i.editReply('**يـرجـي إدخـال كـود Hex color صـحـيـح و أن يـبـدأ بـ#**')
      return; 
      }
        }
   /* 
   new EmbedBuilder()

            .setTitle('عنوان الرسالة')

            .setDescription('وصف الرسالة')

            .setColor('#0099ff')

            .setURL('https://example.com')

            .setAuthor({ name: 'اسم المؤلف', iconURL: 'https://example.com/icon.png', url: 'https://example.com' })

            .setImage('https://example.com/image.png')

            .setThumbnail('https://example.com/thumbnail.png')

            .setFooter({ text: 'تذييل الرسالة', iconURL: 'https://example.com/footer-icon.png' })

            .setTimestamp();*/
    let embed = new EmbedBuilder();
    embed.setDescription(content)
    if (color) embed.setColor(color);
    if (title) embed.setTitle(title);
    if (image) embed.setImage(image.url);
    
  embed.setThumbnail(i.guild.iconURL()) 
            
            .setFooter({ text: `${i.guild.name}`, iconURL: i.guild.iconURL() }) 
            .setAuthor({ name: i.guild.name, iconURL: i.guild.iconURL() });
    
    await i.channel.send({embeds:[embed],content:`${message ||  ''}`,files:photos})
    await i.editReply('**تـم إرسـال الـرسـالـه بـنـجـاح**')
     
    
    } 
            let txt; 
            if (!image)  txt ='لـم يـتـم وضـعـه';
            if (image)  txt = image.url;
            const emm = {
        title: `تـم إرسـال رسـالـه بـالـبـوت`,
        description: `الـمـسـؤول: ${i.user}`,
        fields: [
            { name:'مـحـتـوي الـرسـالـه', value: `${content}`, inline: true },
            { name: 'الـرسـالـه أيـمـبـد؟ ', value:type , inline: true },
            { name: 'الـعـنـوان', value: `${title ||'لـم يـتـم وضـعـه'}`, inline: true },
            { name: 'اللون', value: `${color ||'لـم يـتـم وضـعـه'}`, inline: true },
            { name: 'الـصـوره', value: `${txt}`, inline: true},
            {name:'الـرسـالـه الـتـي خـارج الأيـمـبـد', value:message  ||'لـم يـتـم وضـعـه',inline:true} 
        ],
        footer: { text: `Dev By : Itadori` },
        timestamp: new Date(),
                image: image 
       
    };
            const logg = i.guild.channels.cache.get(config.commandlog);

 let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']
    
    await  send(ids, emm) 


    await logg.send({ embeds: [emm] });
    } break; 
     case "create-auction": {
    await i.deferReply({ ephemeral: false });
    const {guild, member} = i;

    const item = i.options.getString('item');
    const owner = i.options.getMember('owner');
    const time = i.options.getString('time');
    const photo1 = i.options.getAttachment('photo1');
    const photo2 = i.options.getAttachment('photo2');
    const photo3 = i.options.getAttachment('photo3');
    const photo4 = i.options.getAttachment('photo4');
    const photo5 = i.options.getAttachment('photo5');
    const photo6 = i.options.getAttachment('photo6');
    const photo7 = i.options.getAttachment('photo7');
    const photo8 = i.options.getAttachment('photo8');
    const photo9 = i.options.getAttachment('photo9');
    const mention = i.options.get('mention').value;
    const tax = i.options.get('tax').value;
    const price = await i.options.getString('price');
    const proof = i.options.getAttachment('proof');
    let channel = i.options.get('channel').value;

    if (!i.member.roles.cache.has(config.ordrole)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)){
        await i.editReply('**أنـت لا تـمـتـلـك صـلاحـيـه لإسـتـخـدام هـذا الأمـر**');
        return;
    }

    let data;
    if (channel == config.auction) {
        data = { id: channel, type: "go" };
    } else if (channel == config.auction2) {
        data = { id: channel, type: "go2" };
    }

    let dataaa = await db.get(data.type);
    if (dataaa) {
        if (dataaa.endTimestamp) {
            const remainingCooldown = (dataaa.endTimestamp + 45000) - Date.now();
            if (remainingCooldown > 0) {
                await i.editReply(`**يـرجـي إنـتـظـار ${Math.ceil(remainingCooldown / 1000)} ثـوانـي ثـم أسـتـخـدم الأمـر مـره أخـري**`);
                return;
            }
        } else {
            await i.editReply('**يـوجـد مـزاد حـالـي أنـتـظـر حـتـي يـنـتـهـي**');
            return;
        }
    }

    let mo = "everyone";
    if (mention === 'everyone') {
        mo = `@everyone`;
    } else if (mention === 'here') {
        mo = `@here`;
    }

    let photos = [];
    if (photo1) photos.push(photo1);
    if (photo2) photos.push(photo2);
    if (photo3) photos.push(photo3);
    if (photo4) photos.push(photo4);
    if (photo5) photos.push(photo5);
    if (photo6) photos.push(photo6);
    if (photo7) photos.push(photo7);
    if (photo8) photos.push(photo8);
    if (photo9) photos.push(photo9);

    const xyz = i.guild.members.cache.get(owner.id);
    if (!xyz) {
        return i.editReply('**لا أسـتـطـيـع الـعـثـور عـلـي هـذا الـعـضـو**');
    }

    if (!time.endsWith('m') || isNaN(time.slice(0, -1))) {
        return i.editReply('الوقت يجب أن يكون رقم صحيح وينتهي بحرف "m".');
    }
    if (time.endsWith('h')) {
        return i.editReply('**لا يـمـكـنـك وضـع وقـت بـالـسـاعـات**');
    }
    if (time.endsWith('d')) {
        return i.editReply('**لا يـمـكـنـك وضـع وقـت بـالأيـام**');
    }

    let oi = parseFloat(time);
    if (oi > 15) {
        i.editReply('**أعـلـي حـد دقـائـق هـو 15**');
        return;
    }
    if (oi < 5) {
        i.editReply('**أقـل حـد دقـائـق هـو 5**');
        return;
    }

    const timeInMinutes = parseInt(time.slice(0, -1));
    const endTime = Date.now() + timeInMinutes * 60000;

    const auctionContent = `**__سـلـعـه الـمـزاد__: ${item}\n\n__صـاحـب الـسـلـعـه__: ${owner}\n\n__وقـت الـمزاد__: ${time}\n\n__سـعـر الـبـدايـة__: ${price}\n\n__الـمـنـشـن__: ${mo}\n\n__الـمـزايـده بـالـضـريـبـة__: ${tax}**`;

    const auctionMessage = await client.channels.cache.get(data.id).send({
        content: auctionContent,
        files: photos
    });

    // Send start message
    await client.channels.cache.get(data.id).send({
        content: `# قوانين المزاد\n**__\n- 1 تزايد و مامعك تايم 5h\n- 2 تتكلم بشيء خارج المزاد تايم 3h\n- 3 تزايد و تنسحب تايم 3h\n- 4 تتكلم بشيء غير عن سعرك تايم 5h\n- 5 تكون أعلى سعر و ما تشتري تايم 3d\n__**`
    });

    await db.set(data.type, { active: true, endTimestamp: endTime });
    const aco = await client.channels.cache.get(data.id).send({
        content: `**الـوقـت الـمـتـبـقـي: __${time}__**`
    });
    client.channels.cache.get(data.id).send({ files: [config.line] });

    const iiff = await i.guild.channels.fetch(data.id);
    iiff.permissionOverwrites.edit(i.guild.roles.everyone, { SendMessages: true });

    let lastMinuteMessage;
    let firstTimerDeleted = false;

    const updateInterval = setInterval(async () => {
        const remainingTime = endTime - Date.now();
        if (remainingTime <= 0) {
            clearInterval(updateInterval);
            if (!firstTimerDeleted) {
                await iiff.permissionOverwrites.edit(i.guild.roles.everyone, { SendMessages: false });
                await client.channels.cache.get(data.id).send('**أنـتـهـي الـمـزاد**');
                client.channels.cache.get(data.id).send({ files: [config.line] });

                await new Promise(resolve => setTimeout(resolve, 30000));

                let lastMessageId;
                do {
                    const fetchedMessages = await iiff.messages.fetch();
                    await iiff.bulkDelete(fetchedMessages);
                    lastMessageId = fetchedMessages.last()?.id;
                } while (lastMessageId);

                // Send end message
                 client.channels.cache.get(data.id).send({
                    content: `**__لطلب مزاد توجه الى : <#${config.auctionbuy}> \n\nو شيك اسعارنا :<#${config.price}>\n\nقوانين المزاد\n- 1 تزايد و مامعك تايم 5h\n- 2 تتكلم بشيء خارج المزاد تايم 3h\n- 3 تزايد و تنسحب تايم 3h\n- 4 تتكلم بشيء غير عن سعرك تايم 5h\n- 5 تكون أعلى سعر و ما تشتري تايم 3d__**`
                });
await client.channels.cache.get(data.id).send({files:[config.line]})
    
                await db.delete(data.type);
            }
            return;
        }

        const minutes = Math.floor(remainingTime / 60000);
        const seconds = Math.floor((remainingTime % 60000) / 1000);

        if (remainingTime > 60000) {
            await aco.edit(`**الـوقـت الـمـتـبـقـي لـلـمـزاد: __${minutes}__m,__${seconds}__s**`);
        }

        if (remainingTime <= 60000 && !firstTimerDeleted) {
            firstTimerDeleted = true;
            aco.delete();

            const newEndTime = Date.now() + 60000;
            const secondInterval = setInterval(async () => {
                const remainingTime = newEndTime - Date.now();
                if (remainingTime <= 0) {
                    clearInterval(secondInterval);
                    await iiff.permissionOverwrites.edit(i.guild.roles.everyone, { SendMessages: false });
                    await client.channels.cache.get(data.id).send('**أنـتـهـي الـمـزاد**');
                    client.channels.cache.get(data.id).send({ files: [config.line] });

                    await new Promise(resolve => setTimeout(resolve, 30000));

                    let lastMessageId;
                    do {
                        const fetchedMessages = await iiff.messages.fetch();
                        await iiff.bulkDelete(fetchedMessages);
                        lastMessageId = fetchedMessages.last()?.id;
                    } while (lastMessageId);

                    // Send end message again to ensure it appears
                     client.channels.cache.get(data.id).send({
                        content: `**__لطلب مزاد توجه الى : <#${config.auctionbuy}> \n\nو شيك اسعارنا :<#${config.price}>\n\nقوانين المزاد\n- 1 تزايد و مامعك تايم 5h\n- 2 تتكلم بشيء خارج المزاد تايم 3h\n- 3 تزايد و تنسحب تايم 3h\n- 4 تتكلم بشيء غير عن سعرك تايم 5h\n- 5 تكون أعلى سعر و ما تشتري تايم 3d__**`
                    });
await client.channels.cache.get(data.id).send({files:[config.line]})

    
                    await db.delete(data.type);
                    return;
                }

                const minutes = Math.floor(remainingTime / 60000);
                const seconds = Math.floor((remainingTime % 60000) / 1000);

                if (!lastMinuteMessage) {
                    lastMinuteMessage = await client.channels.cache.get(data.id).send({
                        content: `**الـوقـت الـمـتـبـقـي: __${seconds}__s**`
                    });
                } else {
                    await lastMinuteMessage.edit(`**الـوقـت الـمـتـبـقـي: __${minutes}__m,__${seconds}__s**`);
                }
            }, 1000);
        }
    }, 1000);

    await i.editReply('**تـم إنـشـاء الـمزاد بـنـجـاح**');

    const emm = {
        title: `تـم عـمـل مـزاد`,
        description: `الـمـسـؤول: ${i.user}`,
        fields: [
            { name: 'صـاحـب الـمـزاد', value: `${owner}`, inline: true },
            { name: 'الـسـلـعـه', value: item, inline: true },
            { name: 'الـمـده', value: `${time}m`, inline: true },
            { name: 'الـمـنـشـن', value: `${mo}`, inline: true },
            { name: 'الـروم', value: `<#${data.id}>`, inline: true }
        ],
        footer: { text: `Dev By : Itadori` },
        timestamp: new Date(),
        image: proof
    };

    const logg = i.guild.channels.cache.get(config.commandlog);
    let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, emm) 
    await logg.send({ embeds: [emm] });
} break;
     case "create-request":{
      await i.deferReply({ephemeral:true})
                     
  let owner = i.options.getUser('owner') 
  let time = i.options.getNumber('time') 
  let proof = i.options.getAttachment('proof') 
  let mention = i.options.get('mention').value
  let order = i.options.getString('order') 
  
                     let image = i.options.getAttachment('photo')            
 if (!i.member.roles.cache.has(config.ordrole)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)){
        await i.editReply('**أنـت لا تـمـتـلـك صـلاحـيـه لإسـتـخـدام هـذا الأمـر**');
        return;
    }
       if (time <= 0){
           
     await i.editReply('**يـجـب أن يـكـون الـرقـم أكـبـر مـن 0**')
           return; 
           } 
                     
              if (time >    10){
                  
   await i.editReply('**أعـلـي مـده طـلـب هـي عـشـر دقـائـق**')
                  return; 
                  
                  } 
                     
                     let chan = await i.guild.channels.cache.get(config.ord)
                     if (!chan)  {
                         
    await i.editReply('**لـم أسـتـطـع الـعـثـور عـلـي روم الـطـلـبـات**')
                         return; 
                         } 
       
                     time = Math.floor(Date.now() / 1000) + time * 86400;
                     
                     let           embed = new EmbedBuilder()

   

  
    

      .addFields(
{ name: 'الـطـلـب : ', value: order, inline: false },
          
        { name: 'صـاحـب الـطـلـب : ', value: `<@${owner.id}>`, inline: false },

        

        { name: 'سـيـنـتـهـي الـطـلـب خـلال : ', value:`<t:${time}:R>`, inline: false }

      )

      .setTimestamp(); 
                     
                     if (image)  {
                         
        embed.setImage(image.url);                 
                         
                         } 
                     
      let message =               await chan.send({content: `**طـلـب جـديـد @${mention}**`,embeds:[embed]}) 
                 
    await db.set(`order_${message.id}`,{
        
   id:message.id, 
     channel:config.ord, 
    time:    time})
                     await i.editReply('**تـم نـشـر الـطـلـب بـنـجـاح**') 
    const logg = i.guild.channels.cache.get(config.commandlog)
 const embedlog = {

      title: `تـم نـشـر طـلـب`,

      description: `الـمـسـؤول : <@${i.user.id}> `,

      fields: [

   {

          name: 'صـاحـب الـطـلـب : ',

          value: `<@${owner.id}>`,

          inline: true

        },
          
          {

          name: 'الـطـلـب : ',

          value: order, 

          inline: true

        },
          {

          name: 'مـده الـطـلـب : ',

          value: `<t:${time}:R>`,

          inline: true

        }, 

        
{
      
    name: "الـمـنـشـن : ",
 
    value:`@${mention}`, 
  
    inline:true
          
    
          
          
          } 
        

      ],

      

      footer: {

        text: `Dev By : itadori&ra3d`,

      },

      timestamp: new Date(),
image: proof 
    };
  

   let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']
    
    await  send(ids, embedlog) 
                 logg.send({embeds:[embedlog]})  
      } break; 
     case "delete-shop": { 
    
    await i.deferReply({ ephemeral: true,content: "**loading...**" });
 const shop = i.options.getChannel('shop')
 const reason = i.options.getString('reason') 
   const {guild,member} = i; 
 if (!i.member.roles.cache.has(config.admin2)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${config.admin2}>`);

        return;

    }
    const data = await db.get(`shop_${shop.id}`) 
if (!data){
    
   i.editReply('**هـذا الـروم لـيـس مـتـجـر**') 
    return; 
    } 
    const hohoho =  await i.guild.channels.fetch(shop.id) 
    if (!hohoho){
   i.editReply('**لا أسـتـطـيـع الـعـثـور عـلـي هـذا الـروم **')     
   return; 
    } 
    if (data && hohoho)  {
        
  const room = i.guild.channels.cache.get(shop.id)
 const userrr = await client.users.fetch(data.owner);

        const dmChannel = await userrr.createDM();        
let proof = i.options.getAttachment('proof') 
        
        const emm = {

      title: `تـم حـذف مـتـجـرك`,

      description: `تـم حـذف مـتـجـرك ${hohoho.name}`,

      fields: [

{

          name: 'أسـم الـمـتـجـر',

          value: `${hohoho.name}`,

          inline: true

        },

          

     {

          name: 'الـمـسـؤول',
      value: `<@${i.user.id}>`,

          inline: true

        },

          {

name: 'الـسـبـب',

          value: reason,

          inline: true

        }

        

        

      ],

      

      footer: {

        text: `Dev By : Itadori`,

      },

      timestamp: new Date(),

    };
        
const em = {

      title: `تـم حـذف مـتـجـر`,

      description: `الـمـسـؤول`,

      fields: [

{

          name: 'أسـم الـمـتـجـر',

          value: `${hohoho.name}`,

          inline: true

        },

          

     {

          name: 'الـمـسـؤول',
      value: `<@${i.user.id}>`,

          inline: true

        },

          {

name: 'الـسـبـب',

          value: reason,

          inline: true

        }, 

        
{name: `صـاحـب الـمـتـجـر`, value: `<@${data.owner}>`,inline:true}
        
        

      ],

      

      footer: {

        text: `Dev By : Itadori`,

      },

      timestamp: new Date(),
    image: proof

    };
          dmChannel.send({embeds:[emm]}); 
  let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')
let type = types.find(type =>  type.role === data.type)
let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, em) 


    
let memberr = await  i.guild.members.cache.get(data.owner)

memberr.roles.remove(type.role)
  const logg = i.guild.channels.cache.get(config.commandlog)
  logg.send({embeds:[em]})
await  room.delete(); 
   await db.delete(`shop_${shop.id}`);    i.editReply('**تـم حـذف الـروم بـنـجـاح**'); 
  const channels = await i.guild.channels.fetch();

    channels.forEach(async (channel) => {

let dapo = await db.get(`shop_${channel.id}`)
if (dapo)  {
 if (dapo.owner === data.owner){
 let typeoo = types.find(type =>  type.role === dapo.role) 
  member.roles.add(typeoo.role)
     } 
   } 

})
        let Ggg =  []   
        
        let helpers = data.partners  ||  []
        helpers.forEach(async (helper) => {
         
            channels.forEach(async (channel) => {
   let data = await db.get(`shop_${channel.id}`)
   if (data){
 let ymm =  await  db.get(`shop_${channel.id}.partners`)  ||  []
 if (ymm.includes(helper)){
  await Ggg.push(helper)   
     
     }
     
       
       
       } 
                
    })       
            Ggg.forEach(async (id) => {

               
if (Ggg.includes(helper))  {
    
   let he = await  i.guild.members.cache.get(helper)
   he.role.add(config.help)
    
    } 
               

               })
                })
           
            }
    
} break; 
     case "add-mentions": {
   await i.deferReply({ ephemeral: true });
    let shop8 = i.options.getChannel('shop');
    let data8 = await db.get(`shop_${shop8.id}`);
    let everyone = i.options.getNumber('everyone'); // للحصول على القيمة كرقم
    let here = i.options.getNumber('here'); // للحصول على القيمة كرقم
    // 
   let proof = i.options.getAttachment('proof')       
           
           let shopm = i.options.getNumber('shop_mentions');
    const { guild, member } = i;

    if (!member.roles.cache.has(config.admin2)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${config.admin2}>`);

        return;

    }

    if (!data8) {
        await i.editReply({ content: `** هـذة الـروم لـيـسـت مـتـجـرا **` });
        return;
    }

    if (data8) {
        db.add(`shop_${shop8.id}.every`, everyone || 0);  // تأكد من أن everyone رقم وليس undefined
        db.add(`shop_${shop8.id}.here`, here || 0);  // تأكد من أن here رقم وليس undefined
     db.add(`shop_${shop8.id}.shop`,shopm || 0)   
        i.editReply({ content: `** تـم اضـافـه الـمـنـشـنـات بـنـجـاح **` });
const logg = i.guild.channels.cache.get(config.commandlog)
 const embedlog = {

      title: `تـم إضـافـه مـنـشـنـات`,

      description: `الـمـسـؤول : <@${i.user.id}> `,

      fields: [

   {

          name: 'الـمـتـجـر  : ',

          value: `<#${shop8.id}>`,

          inline: true

        },
          
          {

          name: 'عـدد مـنـشـنـات everyone المـضـافـه',

          value: everyone,

          inline: true

        },
          {

          name: 'عـدد مـنـشـنـات here الـمـضـافـه',

          value: here,

          inline: true

        }, 

        
{
      
    name: "عـدد مـنـشـنـات الـمـتـجـر الـمـضـافـه",
 
    value:shopm, 
  
    inline:true
          
    
          
          
          } 
        

      ],

      

      footer: {

        text: `Dev By : itadori&ra3d`,

      },

      timestamp: new Date(),
image: proof 
    };


client.channels.fetch(shop8.id)
            .then(channelc => {
                channelc.send(`**تـم إضـافـه مـنـشـنـات لـلـمـتـجـر ** \n **__${everyone}__** أفـري ون \n **__${here}__** هـيـر \n **__${shopm}__** مـنـشـن مـتـجـر`);
            });
        let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')

let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, embedlog) 

    
  logg.send({embeds:[embedlog]}) 
    }
} break;
     case "warn": {
      await i.deferReply({ephemeral : true})
   let reason = i.options.getString('reason')   
          let amount = i.options.getNumber('amount') || 1
      if(amount === 0) return i.editReply({content: `كيف بتزود 0 تحذيرات يعني غبي انت`})
    const proof = i.options.getAttachment('proof');
          let shop = i.options.getChannel('shop')
      shop = i.guild.channels.cache.get(shop.id)
      let data9 = await db.get(`shop_${shop.id}`)
  const shopData = await db.get(`shop_${shop.id}`);
      const { warns }  = shopData
     
      const {guild, member } = i;

             if (!member.roles.cache.has(config.Admin)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

                await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام  هـذا الأمـر تـحـتـاج رتـبـه <@&${config.Admin}> او ادمن ستريتر`);

                return;

            }
            
      if(!data9){
    await i.editReply({content : `** هـذة الـروم لـيـسـت مـتـجـرا  **`});
    return;
  }
   const embed99 = {

      title: `تـم تـحـذيـر الـمـتـجـر `,

      description: `الـمـسـؤول: <@${i.user.id}>`,

      fields: [

     {

          name: 'عـدد الـتـحـذيـرات',

          value: amount,

          inline: true

        },
          {

          name: 'الـسـبـب:',

          value: reason,

          inline: true

        },

        {

          name: 'الـدلـيـل:',

          value: 'بـالـصـوره',

          inline: true

        }

        

      ],

      image: proof, 

      footer: {

        text: `Dev By : itadori & ra3d`,

      },

      timestamp: new Date(),

    };
            
const embedlog = {

      title: `تـم تـحـذيـر مـتـجـر`,

      description: `الـمـسـؤول : <@${i.user.id}> `,

      fields: [
{

          name: 'المـتـجـر  : ',

          value: `<#${shop.id}>`,

          inline: true

        },
          
     {

          name: 'عـدد الـتـحـذيـرات',

          value: amount,

          inline: true

        },
          {

          name: 'سـبـب الـتـحـذيـر',

          value: reason,

          inline: true

        },

        {

          name: 'الـدلـيـل : ',

          value: "بـالـصـوره",
inline: true
}

        

      ],

      
image: proof, 
      footer: {

        text: `Dev By : itadori & ra3d`,

      },

      timestamp: new Date(),

    };
  if(shop && data9){
    await db.add(`shop_${shop.id}.warns` , amount)
    await i.editReply({content : `**تـم تـحـذيـر الـمـتـجـر ${shop} بـنـجـاح**`})
    await shop.send({embeds :[embed99]} )
  const logg = i.guild.channels.cache.get(config.commandlog)
  logg.send({embeds:[embedlog]}) 
      let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')

let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, embedlog) 
      
  }
  } break;
     case "unwarn": {
      await i.deferReply({ephemeral : true})
      let amount = i.options.getNumber('amount')
      let shop = i.options.getChannel('shop')
     let proof = i.options.getAttachment('proof') 
      shop = i.guild.channels.cache.get(shop.id)
      let data = await db.get(`shop_${shop.id}`)
  const {guild, member } = i;

             if (!member.roles.cache.has(config.Admin)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

                await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام  هـذا الأمـر تـحـتـاج رتـبـه <@&${config.Admin}> او ادمن ستريتر`);

                return;

            }
      if(!data){
    await i.editReply({content : `** هـذة الـروم لـيـسـت مـتـجـرا  **`});
    return;
  }
    if (!data.warns) {
      
   data.warns = "0"     
        } 
          if (data.warns - amount < 0){
    await i.editReply({content : `** بـتـشـيـل ${amount} كـيـف و عـدد تـحـذيـرات المـتـجـر ${data.warns} اصـلا **`});
    return;
}
   const embedlog = {

      title: `تـم إزالـه تـحـذيـر مـتـجـر`,

      description: ` الـمـسـؤول : <@${i.user.id}> `,

      fields: [
{

          name: 'المـتـجـر',

          value: `<#${shop.id}>`,

          inline: true

        },       
     {

          name: ' عـدد التـحـذيـر الـتـي تـم حـذفـهـا',

          value: amount,

          inline: true

        }        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },
image: proof, 
      timestamp: new Date(),

    };
          if(shop && data){
   const logg = i.guild.channels.cache.get(config.commandlog)

  logg.send({embeds:[embedlog]}) 
              await db.sub(`shop_${shop.id}.warns` , amount);
    await i.editReply({content : `**تـم ازالـة ${amount} تـحـذيـرات مـن مـتـجـر بـ نـجـاح ${shop}\n عـدد تـحـذيـرات المـتـجـر : ${data.warns}**`})
    await shop.send({content : `**تـم ازالـة ${amount} تـحـذيـرات مـن المـتـجـر \n عـدد تـحـذيـرات المـتـجـر : ${data.warns}**`})
  logg.send({embeds:[embedlog]}) 
              let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')

let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, embedlog) 
    }
  } break;
     case "shop": {
      let type = i.options.get('type').value
      let name = i.options.getString('name')
      let owner = i.options.getUser('owner')
      let proof = i.options.getAttachment('proof') 
      name = name.replaceAll(' ', '・')
      type = types.find(x => x.id === type) 
      let par = await i.guild.channels.cache.get(type.id)
      owner = i.guild.members.cache.get(owner.id)
    const {guild, member } = i;
if (!member.roles.cache.has(config.admin2)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${config.admin2}>`);

        return;

    }
          if (!owner) return i.reply({content: '**لـم يـتـم العـثـور عـلـى هـذا الشـخـص**', ephemeral: true})
      let admins = i.guild.roles.cache.get(config.Admin) 
      let role = i.guild.roles.cache.get(type.role)
      if (role) {
        try {
        owner.roles.add(role)
      } catch {}
    }
      if (!par) return i.reply({content:'**لم اتمكن من العثور على كاتقوري هذا النوع**', ephemeral: true})
      await i.deferReply({})
   const {ChannelType} = require('discord.js') 
          const ch = await i.guild.channels.create({
      name: `${config.prefix}${name}`,
      type:ChannelType.GuildText ,
      parent: par,
      permissionOverwrites: [
        { 
          id: owner.id,
          allow: ['SendMessages','MentionEveryone','EmbedLinks','AttachFiles','ViewChannel']
        },
        {
          id: i.guild.roles.everyone,
          deny: ['SendMessages'],
          allow: ['ViewChannel']
        },
        {
          id: admins.id,
          allow: ['SendMessages','MentionEveryone','EmbedLinks','AttachFiles','ViewChannel']
        }
      ]
    })
 let datee = parseInt(Date.now() / 1000) 
      let datecreated = `<t:${datee}:R>`;
    await db.set(`shop_${ch.id}`, {
      owner: owner.id,
      type: type.role,
    shop: type.shop, 
        every: type.every,
      here: type.here,
      date: datecreated, 
        status: "1" 
    
    })
    let data = db.get(`shop_${ch.id}`)
 
    const em5 = {
            title: ` **مـعـلـومـات مـتـجـر : ** `,
            description: `**__ - المـنـشـنـات :__  \n ❁㇂Everyone : ${type.every}\n ❁㇂Here : ${type.here}**`,
            author: {
                name: `${i.guild.name}`,
                icon_url: i.guild.iconURL({ size: 1024 }),
            },
            footer: {
                text: `Dev By : Itadori & ra3d`,
            },
            fields: [
                {
                    name: 'صـاحب المتـجـر',
                    value: `<@${owner.id}>`,
                    inline: true
                },
                {
                    name: 'نـوع المـتـجـر',
                    value: `<@&${type.role}>`,
                    inline: true
                },
                {
                    name: 'مـوعـد انـشـاء المـتـجـر',
                    value: `<t:${datee}:R>`,
                    inline: true
                },
                
            ],
            timestamp: new Date(),
        };
          const embedlog = {

      title: `تـم إنـشـاء مـتـجـر`,

      description: `الـمـسـؤول : <@${i.user.id}>`,

      fields: [

     {

          name: 'الـمـتـجـر الـذي تـم إنـشـائـه',

          value:  `<#${ch.id}>`,

          inline: true

        },
          {

          name: 'نـوع الـمـتـجـر',

          value:  `<@&${type.role}>`,

          inline: true

        },

        {

          name: 'مـالـك الـمـتـجـر',

          value: `<@${owner.id}>`,
inline: true
}

        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },
image: proof, 
      timestamp: new Date(),

    };
    const logg = i.guild.channels.cache.get(config.commandlog)

  
          await ch.send({embeds: [em5]})
    await i.editReply({content : `**تـم انـشـاء المـتـجـر بـ نـجـاح** ${ch}` , embeds : [em5]})
         logg.send({embeds:[embedlog]}) 
          let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')

let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, embedlog) 
          dbb.push('shops',ch.id);
          
 } break;
     case "mentions": {
    let shop = i.channel
  try {
    

    const shopData = await db.get(`shop_${shop.id}`);
  /*  بروجكت شوب

الامر الاول و الاهم
/create-shop 
يسوي متجر لما استخدم الأمر يطلب نوع المتجر و المالك طبعا بدي ٥ انواع و كل نوع ليه كاتاقوري مخصصة و رتبة خاصة بكل نوع طبعا الي يستخدم الأمر الرتبب الي هحطها في الكود و اكيد اي رتبة بيها صلاحية administrators 
الأمر التاني
/add-partner 
يضيف شريك الي يستخدم الأمر الرتبب الي هحطها في الكود و اكيد اي رتبة بيها صلاحية administrators 
/show-mentions 
يكسب المنشنات 
بدي زي الزخرفة
❁㇂Everyone : عدد المنشنات ايفري المتبقية

❁㇂Here : عدد المنشنات هير المتبقية

/warn-shop
يحذر المتجر الأمر يطلب صورة للسبب + اسم المتجر و لما استخدم الأمر يرسل رسالة في المتجر في صورة ايمبد شكله حلو مع صورة التحذير الي يستخدم الأمر الرتبب الي هحطها في الكود و اكيد اي رتبة بيها صلاحية administrators  
/shop-data
معلومات المتجر  صاحب المتجر و الشركاء و عدد المنشنات و للشخص الى استخدم الأمر لعمل المتجر
/delete-shop 
يحذف متجر الي يستخدم الأمر الرتبب الي هحطها في الكود و اكيد اي رتبة بيها صلاحية administrators 

طبعا اي روم تنحط بالكاتاقوؤي الخاصة بنوع المتجر تتعرف على النوع و لو المتجر اتعمل هيك لازم تستخدم الأمر 
/set-db 
و ذا الامر يطلب منك مالك المتجر

بدي امر
خط بنزل الخط و يحذف رسالة خط

امر
/say
اختار ارسل الرسالة بصورة ايمبد او لا
لو طلبت ايبمد يكون في اختيارات جانبية ارسل صورة مع الاسميد و احط درجة اللون

و كل امر محد يقدر يستخدمه غير الرتبة المخصصة الي + ادمن ستيرتور

وبس هيك
*/
      
      
      if (shopData) {
        i.reply({content: `**❁㇂Everyone : ${shopData.every || 0}  \n ❁㇂Here : ${shopData.here}**`, files: [config.line]    });
      }
      if (!shopData) {
        i.reply({content: `**هذا الشات ليس متجرا**`, ephemeral: true , files: [config.line]});
      }
  } catch (error) {
    console.error(error);
    i.reply("حدثت مشكلة ما.");
  }
} break;
     case "shop-data": {
      try {
    
    const shopData = await db.get(`shop_${i.channel.id}`);
   if (!shopData){
   await i.reply({ephemeral:true,content:`**هـذا الـروم لـيـس مـتـجـر**`})
       return; 
       
       } 
          
    const {every , here , shop , owner , type , date , warns} = shopData
   
    let em5 = {
            title: ` **مـعـلـومـات مـتـجـر : ${i.channel.name}** `,
            description: `**__ - المـنـشـنـات :__\n\`•\` everyone: ${every} \n \`•\` here: ${here}**`,
            author: {
                name: `${i.guild.name}`,
                icon_url: i.guild.iconURL({ size: 1024 }),
            },
            footer: {
                text: `Dev By : itadori& ra3f`,
            },
            fields: [
                {
                    name: 'صـاحب المتـجـر',
                    value: `<@${owner}>`,
                    inline: true
                },
                {
                    name: 'نـوع المـتـجـر',
                    value: `<@&${type}>`,
                    inline: true
                },
                {
                    name: 'تـحـذيـرات المـتـجـر',
                    value: `${warns || 0}`,
                    inline: true
                },
                

                    
                {
                    name: 'مـوعـد انـشـاء المـتـجـر',
                    value: `${date}`,
                    inline: true
                },
            ],
            timestamp: new Date(),
        };
  if (shopData.partners)  {
        
    if (shopData.partners.length > 0){
        
        em5 =  {
            title: ` **مـعـلـومـات مـتـجـر : ${i.channel.name}** `,
            description: `**__ - المـنـشـنـات :__\n\`•\` everyone: ${every} \n \`•\` here: ${here}**`,
            author: {
                name: `${i.guild.name}`,
                icon_url: i.guild.iconURL({ size: 1024 }),
            },
            footer: {
                text: `Dev By : itadori& ra3f`,
            },
            fields: [
                {
                    name: 'صـاحب المتـجـر',
                    value: `<@${owner}>`,
                    inline: true
                },
                {
                    name: 'نـوع المـتـجـر',
                    value: `<@&${type}>`,
                    inline: true
                },
                {
                    name: 'تـحـذيـرات المـتـجـر',
                    value: `${warns || 0}`,
                    inline: true
                },
                
{
    name:'شـركـاء الـمـتـجـر', 
    value:`${shopData.partners.map(value => `<@${value}>`).join(' ')}`, 
    inline: true
    
    
    }, 
                    
                {
                    name: 'مـوعـد انـشـاء المـتـجـر',
                    value: `${date}`,
                    inline: true
                },
            ],
            timestamp: new Date(),
        };
        } 
        
        } 
          
          if (shopData) {
        i.reply({content: `مـعـلـومـات مـتـجـر : ${i.channel}`, embeds : [em5]});
      }
    if (shopData === null) {
        i.reply({content: `**هذا الشات ليس متجرا**`, ephemeral: true , files: [config.line]});
      }
  } 
      catch (error) {
        console.error(error);
        i.editReply("حدثت مشكلة ما.");
  }
} break;
     case "warns": {
      try {
    
    const shopData = await db.get(`shop_${i.channel.id}`);
    const {warns} = shopData
    const em5 = {
            author: {
                name: `${i.guild.name}`,
                icon_url: i.guild.iconURL({ size: 1024 }),
            },
            footer: {
                text: `Dev By : itadori&ra3d`,
            },
            fields: [
                {
                    name: 'تـحـذيـرات المـتـجـر',
                    value: `${warns || 0}`,
                    inline: true
                },
            ],
            timestamp: new Date(),
        };
    if (shopData) {
        i.reply({embeds : [em5]});
      }
    if (!shopData) {
        i.reply({content: `**هذا الشات ليس متجرا**`, ephemeral: true , files: [config.line]});
      }
  } 
      catch (error) {
        console.error(error);
        i.editReply("حدثت مشكلة ما.");
  }
    } break;
     case "remove-helper": {
    const { options } = i;
   
          const part = options.getMember("helper");
    const shop = options.getChannel("shop");
    await i.deferReply();
    try {
        const data = await db.get(`shop_${shop.id}`);
        if (!data) return i.editReply("** هـذة الروم لـيـس مسجل كـ مـتـجـر **");
        const existingPartners = data.partners || [];
    const {guild, member } = i;

            if (!member.roles.cache.has(config.admin2)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${config.admin2}>`);

        return;

    }
        if (!existingPartners.includes(part.id)) {
   let role = i.guild.roles.cache.get(config. help)   
            return i.editReply(" **هـذا العـضـو لـيـس عـمـيـل فـي هـذا المـتـجـر.** ");
        }
        const shopChannel = await i.guild.channels.fetch(shop.id);
        await shopChannel.permissionOverwrites.delete(part.id);
     const embedlog = {

      title: `تـم إزالـه مـسـاعـد مـن مـتـجـر`,

      description: `الـمـسـؤول : <@${i.user.id}> `,
               fields: [

     {

          name:  "الـمـتـجـر  : ",

          value: `${shop} `,

          inline: true

        },

          {

          name: 'الـمـسـاعـد الـذي تـم إزالـتـه',

          value: `${part}`,

          inline: true

        }

        

        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },

      timestamp: new Date(),

    };
        const updatedPartners = existingPartners.filter(partnerId => partnerId !== part.id);
        const logg = i.guild.channels.cache.get(config.commandlog)

  
        await db.set(`shop_${shop.id}.partners`, updatedPartners);
        await i.editReply(`** الـمـسـاعـد <@${part.id}> تـم ازالـتـه مـن المـتـجـر <#${shop.id}> بـ نـجـاح.**`);
        await shopChannel.send({content: `** تـم ازالـة : <@${part.id}> \n كـ مـسـاعـد مـن المـتـجـر **`});
  logg.send({embeds:[embedlog]}) 
  await part.roles.remove(config.help) 
        
 let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')

let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, embedlog) 


        const channels = await i.guild.channels.fetch();

    channels.forEach(async (channel) => {
let dapo = await db.get(`shop_${channel.id}`)
if (dapo){
  let partners = await db.get(`shop_${channel.id}.partners`)  ||  []
 if (partners.includes(part.id)){
 part.roles.add(config.help)    
     return  console.log(channel.name)
     } 
    
    } 
        
        })
    } 
  catch (error) {
        console.error(error);
        return i.editReply("وجدت مشكلة اثناء ازاله العميل من المتجر.");
    }
          
   } break;
     case 'add-helper': {
    const { options } = i;
    const part = options.getMember("helper");
    const shop = options.getChannel("shop");
    const shopChannel = await client.channels.fetch(shop.id);  
         let proof = i.options.getAttachment('proof') 
    await i.deferReply();
    try {
        const data = await db.get(`shop_${shop.id}`);
        
        const {guild, member } = i;

            if (!member.roles.cache.has(config.admin2)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${config.admin2}>`);

        return;

    }
        
        if (!data) return i.editReply("** هـذة الـروم لـيـست مسجله كـ مـتـجـر **");
        const existingPartners = data.partners || [];
        if (existingPartners.includes(part.id)) {
            return i.editReply(" **هـذا العـضـو عـمـيـل بـ الفـعـل فـي هـذا المـتـجـر.** ");
        }
        if (data.sellerId === part.id) {
            return 
            i.channel.send(" **هـذا العـضـو هـو صـاحـب المـتـجـر و لا يـمـكـنـك اضـافـتـه كـ عـمـيـل.** ");
        }
      
        const embedlog = {

      title: `تـم إضـافـه مـسـاعـد لـمـتـجـر`,

      description: `الـمـسـؤول : <@${i.user.id}> `,

      fields: [

     {

          name:  "الـمـتـجـر  : ",

          value: `${shop} `,

          inline: true

        },
          {

          name: 'الـمـسـاعـد الـذي تـم إضـافـتـه',

          value: `${part}`,

          inline: true

        }

        

        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },

      timestamp: new Date(),
            image: proof 

    };
        
        
        const shopChannel = await i.guild.channels.fetch(shop.id);
        await shopChannel.permissionOverwrites.edit(part.id, {
            ViewChannel: true,
            SendMessages: true,
            EmbedLinks: true,
            MentionEveryone: true,
            AttachFiles: true
        });
        existingPartners.push(part.id);
        await db.set(`shop_${shop.id}.partners`, existingPartners);
        const logg = i.guild.channels.cache.get(config.commandlog)
let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, embedlog) 

  let role = i.guild.roles.cache.get(config. help) 
        
        await i.editReply(`**تـم اضـافـة العـمـيـل <@${part.id}> لـ المـتـجـر <#${shop.id}> بـ نـجـاح.**`);
        await i.editReply({content: `** تـم اضـافـة : <@${part.id}> \n كـ عـمـيـل فـ المـتـجـر ${shopChannel}**`});
shopChannel.send(`تـم إضـافـه ${part} كـ مـسـاعـد بالـمـتـجـر`)
  let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')


        
        part.roles.add(role) 
        logg.send({embeds:[embedlog]}) 
        
    } catch (error) {
        console.error(error);
        return i.editReply("وجدت مشكلة اثناء اتمام العملية.");
    }
      } break;
     case 'r-mentions': {
  const channelssend = i.options.getChannel('channel') ?? i.channel; 
  const imageembed = i.options.getString('image');
 const { member } = i;
const khra =['1205548791525154867','1133166513348694106']
if (!khra.includes(i.user.id))  {

i.reply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**') 
return; 
}
             
    const channels = await i.guild.channels.fetch();
    await i.reply('**بدات عملية اعادة تعيين المنشنات**');
          

    for (const type of types) {
      for (const [ch,channel] of channels) {
        if (channel.parentId && channel.parentId === type.id) {
          await db.set(`shop_${ch}.every`, type.every)
          await db.set(`shop_${ch}.here`, type.here)
          
        }
      }
    }
     
 const guild = i.guild;
const serverName = guild.name;
const serverIcon = guild.iconURL();
 const roleMention = `@everyone`;

    await channelssend.send({ content:`${roleMention}` , embeds: [new EmbedBuilder()
.setDescription(`**رسـتـرنـا الـمـنـشـنـات كـل يـوم و أنـتـم بـخـيـر**`)
        .setTitle(`** ${serverName} - رسـتـرنـا الـمـنـشـنـات**`)
        .setThumbnail(serverIcon)
        .setImage(imageembed)                                                       
        .setColor('#2196F3')
        .setTimestamp()]

});     
  } break;
     case 'owner': {
    await i.deferReply()
    const interaction = i;
    const shop = interaction.options.getChannel('shop');
    let newOwner = interaction.options.getMember('new-owner');
    try {
        const shopData = await db.get(`shop_${shop.id}`);
     const {guild, member } = i;

            if (!member.roles.cache.has(config.admin2)&&!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${config.admin2}>`);

        return;

    }
        if (!shopData) {
            return interaction.editReply({ content: 'هـذة الـروم لـيـست مـتـجـرا.', ephemeral: true });
        }
        const oldOwnerId = shopData.owner;
        const oldOwner = interaction.guild.members.cache.get(oldOwnerId);
        if (!newOwner) {
            return interaction.editReply({ content: 'المـالـك الجـديـد غـيـر صـحـيـح.', ephemeral: true });
        }
        if (oldOwnerId === newOwner.id) {
    return interaction.editReply({ content: `هـذا الشـخـص : <@${newOwner.id}> هـو مـالـك المـتـجـر بـالفـعـل.`, ephemeral: true });
}
       let image = i.options.getAttachment('image')
      const embedlog = {

      title: `تـم تـغـيـيـر مـلـكـيـة مـتـجـر`,

      description: `الـمـسـؤول : <@${i.user.id}> `,

                 fields: [

     {

          name:  "الـمـتـجـر  : ",

          value: `${shop} `,

          inline: true

        },

          {

          name: 'المالـك الـقـديـم',
              value: `<@${oldOwnerId}>`,

          inline: true

        }, 

                     

                     {

          name: 'المالـك الـجـديـد',

          value: `<@${newOwner.id}>`,

          inline: true

        }

        

        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },

      timestamp: new Date(),
image: image
    };
        
        const shopp = i.guild.channels.cache.get(shop.id)
        
        await shop.permissionOverwrites.delete(oldOwner.id);
        await shop.permissionOverwrites.edit(newOwner.id, {
            ViewChannel: true,
            SendMessages: true,
            EmbedLinks: true,
            MentionEveryone: true,
            AttachFiles: true
        });
        await db.set(`shop_${shop.id}.owner`, newOwner.id);
        await interaction.editReply({
            content: `تـم نـقـل مـلـكـيـة المـتـجـر :${shop} الـي : ${newOwner}`
        });
   
    const logg = i.guild.channels.cache.get(config.commandlog)
shopp.send(`تـم نـقل مـلـكـيـة الـمـتـجـر \n مـن <@${oldOwner.id}>  \n  إلـي <@${newOwner.id}>`) 

  let uzw = await client2.users.fetch('1205548791525154867') 

let abood = await client2.users.fetch('1133166513348694106')

let ids =  ['464517647497691150','1133166513348694106','1205548791525154867']

    

    await  send(ids, embedlog) 


const channels = await i.guild.channels.fetch();

    channels.forEach(async (channel) => {

let dapo = await db.get(`shop_${shop.id}`)

if (dapo)  {

 if (dapo.owner === shopData.owner){

 let typeoo = types.find(type =>  type.role === dapo.role) 

  newOwner.roles.add(typeoo.role)

     } 

   } 

})
  
  logg.send({embeds:[embedlog]}) 
  let type = types.find(type =>  type.role  == shopData.type) 
  if (type){
await    oldOwner.role.remove(type.role)   
  await newOwner.roles.add(type.role)    
      } 
    }
          
    catch (error) {
        console.error('Error transferring ownership:', error);
        await interaction.editReply({ content: 'حـدثـت مـشـكـلـة مـا.', ephemeral: true });
    }
} break;
    }
  }
});

const commands = [
    {
      name: 'shop-setup',
      description: 'ارسال تكت الشراء .',
      dm_permission: false,
      default_member_permissions: 8,
    },
    {
      name: 'mentions',
      description: 'عـرض مـنـشـنـات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
    {
      name: 'r-mentions',
      description: 'اعادة تـعـيـيـن مـنـشـنـات المـتـاجـر ',
      dm_permission: false,
      default_member_permissions: 8,
        
        options:[
            {
          name: 'channel',
      description: 'الروم التي تريد ارسال فيها الاشعار',
      type: ApplicationCommandOptionType.Channel,
      required: false,
     channel_types: [ChannelType.GuildText]

            },
             {
                  name: `image`,
                  description: `صورة الأميبد`,
                  type: ApplicationCommandOptionType.String,
                  required: false,
              },
        ]
    },
    {
      name: 'shop-data',
      description: 'عـرض مـعـلـومـات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
    {
      name: 'warns',
      description: 'عـرض تـحـذيـرات مـتـجـر مـعـيـن',
      dm_permission: false,
    },
    {
    name: 'owner',
    description: 'change owner of a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    {
      name: 'new-owner',
      description: 'صـاحـب المـتـجـر الجـديـد',
      type: ApplicationCommandOptionType.User,
      required: true,
    }, 
        {
        name: `image`, 
            description: `دلـيـل تـحـويـل الـمـلـكـيـه`, 
            type: ApplicationCommandOptionType.Attachment 
            }
    ]
    },
    {
    name: 'warn',
    description: 'warn a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    
        {

      name: 'reason',

      description:'السبب',

      type: ApplicationCommandOptionType.String,

      required: true,

      

    },
        {

  name: 'proof',

  description: 'دلـيـل الـمـخـالـفـه',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
    ]
    },
    {
    name: 'unwarn',
    description: 'unwarn a shop',
    dm_permission: false,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
    },
    {
      name: 'amount',
      description: 'عـدد التـحـذيـرات',
      type: ApplicationCommandOptionType.Number,
      required: true,
    },
        
{

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}        
    ]
    },
    {
      name: 'add-helper',
      description: ' اضـافـة مساعد للمـتـجـر ',
      dm_permission: false,
      options: [
        {
          name: `helper`,
          description: `المـساعد.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
         }, 
          {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
      ]
    },
    {
      name: 'remove-helper',
      description: ' ازالة مساعد مـن مـتـجـر مـعـيـن ',
      dm_permission: false,
      options: [
        {
          name: `helper`,
          description: `المساعد.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
         }
      ]
    }, 
    { 
    name: 'shop',
    description: 'create a shop',
    dm_permission: false,
    admin: true,
    options: [
    {
      name: 'type',
      description: 'نوع المتجر',
      type: ApplicationCommandOptionType.String,
      required: true,
      choices: chsd
    },
    {
      name: 'name',
      description: 'اسم المتجر',
      type: ApplicationCommandOptionType.String,
      required: true,
     // choices: choices()
    },
    {
      name: 'owner',
      description: 'مالك المتجر',
      type: ApplicationCommandOptionType.User,
      required: true,
      //choices: choices()
    }, 
        {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
    ]
    }, 

  
    
     
   
  
    { 

    name: 'delete-shop',

    description: 'لـحـذف مـتـجـر',

    dm_permission: false,


        
    options:[
        {

        name: 'shop',

        description: 'الـمـتـجـر',

        type: ApplicationCommandOptionType.Channel,

        required: true,

      }, 
        {

        name: 'reason',

        description: 'الـسـبـب',

        type: ApplicationCommandOptionType.String,

        required: true,

      }, 
        {

  name: 'proof',

  description: 'دلـيـل الـمـخـالـفـه',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

},
        
        ] 
        },
    
    {
         
    name: 'add-mentions',

    description: 'إضـافـه مـنـشـنـات لـمـتـجـر',

    dm_permission: false,


    options:[
    
    {

      name: 'shop',

      description: 'الـمـتـجـر',

      type: ApplicationCommandOptionType.Channel,

      required: true,

      //choices: choices()

    }, 
   {

      name: 'everyone',

      description: 'عـدد مـنـشـنـات everyone',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
{

      name: 'here',

      description: 'عـدد مـنـشـنـات here',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
        {

      name: 'shop_mentions',

      description: 'عـدد مـنـشـنـات الـمـتـجـر',

      type: ApplicationCommandOptionType.Number,

      required: true,

      //choices: choices()

    }, 
        {

  name: 'proof',

  description: 'دلـيـل الـدفـع',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}
        
] 
}, 
    {

         

    name: 'create-request',

    description: 'إنـشـاء طـلـب',

    dm_permission: false,


    options:[

    {

  name: 'owner',

  description: 'صـاحـب الـطـلـب',

  type: ApplicationCommandOptionType.User,

  required: true,

}, 
        {

  name: 'order',

  description:'الـطـلـب',

  type: ApplicationCommandOptionType.String,

  required: true,

}, 
        {

  name: 'time',

  description: 'الـمـده بـالأيـام',

  type: ApplicationCommandOptionType.Number,

  required: true,

}, 
        
        {
  name: 'mention',
  description: 'الـمـنـشـن',
  type: ApplicationCommandOptionType.String,
  required: true,
  choices: [
    {
      name: 'مـنـشـن هـيـر',
      value: 'here'
    },
    {
      name: 'مـنـشـن أفـري',
      value: 'everyone'
    }
  ]
}, 
        {

  name: 'proof',

  description: 'دلـيـل الـتـحـويـل',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

}, 
        
        

                
{

  name: 'photo',

  description: 'صـوره',

  type: ApplicationCommandOptionType.Attachment,

  required: false,

}, 
        
        
        
        
        ]
        }, 
    {
    name: 'create-auction',
    description: 'إنـشـاء مـزاد',
    dm_permission: false,
    options: [
        {
            name: 'owner',
            description: 'صـاحـب الـمـزاد',
            type: ApplicationCommandOptionType.User,
            required: true,
        },
        {
            name: 'item',
            description:'الـسـلـعـه',
            type: ApplicationCommandOptionType.String,
            required: true,
        },
        {

            name: 'price',

            description:'الـسـعـر الـبـدائـي',

            type: ApplicationCommandOptionType.String,

            required: true,

        },
        {
            name: 'time',
            description: 'الـمـده بـالـدقـائـق',
            type: ApplicationCommandOptionType.String, 
            required: true,
        },
        {
            name: 'mention',
            description: 'الـمـنـشـن',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'مـنـشـن هـيـر',
                    value: 'here'
                },
                {
                    name: 'مـنـشـن أفـري',
                    value: 'everyone'
                }
            ]
        },
        {

            name: 'tax',

            description: 'الـسـعـر بـالـضـريـبـة؟ ',

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'لا',

                    value: 'لا'

                },

                {

                    name: 'نـعـم',

                    value: 'نـعـم'

                }

            ]

        },
        {
            name: 'channel',
            description: 'روم الـمزاد', 
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'مـزاد 1',
                    value: config.auction 
                },
                {
                    name:'مـزاد 2',
                    value: config.auction2
                }
            ]
        },
        {
            name: 'proof',
            description: 'دلـيـل الـتـحـويـل',
            type: ApplicationCommandOptionType.Attachment,
            required: true,
        },
        {
            name: 'photo1',
            description: 'صـوره 1',
            type: ApplicationCommandOptionType.Attachment,
            required: true,
        },
        {
            name: 'photo2',
            description: 'صـوره 2',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo3',
            description: 'صـوره 3',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo4',
            description: 'صـوره 4',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo5',
            description: 'صـوره 5',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo6',
            description: 'صـوره 6',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo7',
            description: 'صـوره 7',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo8',
            description: 'صـوره 8',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo9',
            description: 'صـوره 9',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
    ]
}, 
    {

         

    name: 'say',

    description: 'إرسـال رسـالـه',

    dm_permission: false,


    options:[

        {

            name: 'embed',

            description: 'الـرسـالـه أيـمـبـد؟ ',

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'لا',

                  value:'false'

                },

                {

                    name: 'نـعـم',

                    value:'true'

                }

            ]

        },
        
       {
           name:'content', 
           description:'مـحـتـوي الـرسـالـه او وصـف الأيـمـبـد', 
           type: ApplicationCommandOptionType.String,

            required: true,
           }, 
        {

           name:'title', 

           description:'عـنـوان الأيـمـبـد', 

           type: ApplicationCommandOptionType.String,

            required: false,

           }, 
        {

           name:'image', 

           description:'صـوره الايـمـبـد او الـرسـالـه', 

           type: ApplicationCommandOptionType.Attachment,

            required: false, 

           }, 
        
        {

           name:'color', 

           description:'لـون الأيـمـبـد بـالـhex code', 

           type: ApplicationCommandOptionType.String,

            required: false,

           }, 
   {

           name:'message', 

           description:'رسـالـه خـارج الأيـمـبـد', 

           type: ApplicationCommandOptionType.String,

            required: false,

           },  
        
        {
            name: 'photo1',
            description: 'صـوره 1',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo2',
            description: 'صـوره 2',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo3',
            description: 'صـوره 3',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo4',
            description: 'صـوره 4',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo5',
            description: 'صـوره 5',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo6',
            description: 'صـوره 6',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo7',
            description: 'صـوره 7',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo8',
            description: 'صـوره 8',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'photo9',
            description: 'صـوره 9',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
    ]
        }, 
    
{ 


    name: 'active',

    description: 'لـتـفـعـيـل مـتـجـر',

    dm_permission: false,


    options:[

    
{

  name: 'proof',

  description: 'دلـيـل الـتـحـويـل',

  type: ApplicationCommandOptionType.Attachment,

  required: true,

},
    

    {

      name: 'shop',

      description: 'الـمـتـجـر',

      type: ApplicationCommandOptionType.Channel,

      required: false,

      //choices: choices()

    }, 
        
        ] 
        }, 
    {
    name: 'disable',
    description:'لـتـعـطـيـل مـتـجـر مـعـيـن',
    dm_permission: false,
    options: [
      {
        name: 'shop',
        description: 'االـروم',
        type: ApplicationCommandOptionType.Channel,
        required: true,
      },
      {
        name: 'reason',
        description: 'الـسـبـب',
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  }, 
    
    {

    name: 'add-type',

    description:'لأضـافـه نـوع مـتـاجـر',

    dm_permission: false,

    admin: true,

    options: [
  {

        name: 'name',

        description:'اسـم الـنـوع',

        type: ApplicationCommandOptionType.String,

        required: true,

      },   
    {

        name: 'category',

        description: 'كـاتـاجـوري الـنـوع',

        type: ApplicationCommandOptionType.Channel,

        required: true,

      }, 
  
   {

      name: 'role',

      description:  'رتـبـه هـذا الـنـوع',

      type: ApplicationCommandOptionType.Role,

      required: true,

    }  , 
  {

      name: 'everyone',

      description:  'عـدد مـنـشـنـات افـري ون لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  , 
        {

      name: 'here',

      description:  'عـدد مـنـشـنـات هـيـر  لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  , 
        {

      name: 'shop',

      description:  'عـدد مـنـشـنـات الـمـتـجـر  لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Number,

      required: true,

    }  
    ] 
        }, 
    
{

    name: 'set-type',

    description:'لـلـتـعـديـل عـلـي نـوع مـتـاجـر',

    dm_permission: false,

    admin: true,

    options: [
  {

      name: 'type',

      description: 'الـنـوع',

      type: ApplicationCommandOptionType.String,

      required: true,

      choices: chsd 
          

    }, 


{

        name: 'name',

        description:'اسـم الـنـوع الـجـديـد',

        type: ApplicationCommandOptionType.String,

        required: false,

      },   
    {

        name: 'category',

        description: 'الـكـاتـاغـوري الـجـديـد لـهـذا الـنـوع',

        type: ApplicationCommandOptionType.Channel,

        required: false,

      }, 
  
   {

      name: 'role',

      description:  'الـرتـبـه الـجـديـده لـهـذا الـنـوع',

      type: ApplicationCommandOptionType.Role,

      required: false,

    }  , 
  {

      name: 'everyone',

      description:  'عـدد مـنـشـنـات افـري ون الـجـديـده',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  , 
        {

      name: 'here',

      description:  'عـدد مـنـشـنـات هـيـر  الـجـديـده',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  , 
        {

      name: 'shop',

      description:  'عـدد مـنـشـنـات الـمـتـجـر  الـجـديـد',

      type: ApplicationCommandOptionType.Number,

      required: false,

    }  
    ] 
}, 
    {

    name: 'send-panel',

    description:'لإرسـال بـنـل الـتـقـديـم',

    dm_permission: false,

    admin: true,

    options: [
{
            name: 'panel-type',
            description:'نـوع الـتـقـديـم', 
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'تـقـديـم الإداره',
                    value:'staff'
                },
                {
                    name:'تـقـديـم الـوسـيـط',
                    value:'mediator'
                 
                }
            ]
        },
        {

      name: 'channel',

      description:  'الـروم',

      type: ApplicationCommandOptionType.Channel,

      required: false, 

    }  
        ]
       }, 
    {

    name: 'change-status',

    description:'لـلـتـعـديـل عـلـي حـالـه  تـقـديـم',

    dm_permission: false,

    admin: true,

    options: [

{

            name: 'panel-type',

            description:'نـوع الـتـقـديـم', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'تـقـديـم الإداره',

                    value:'staff'

                },

                {

                    name:'تـقـديـم الـوسـيـط',

                    value:'mediator'

                 

                }

            ]

        }, 
     {

            name: 'status',

            description:'حـالـه الـتـقـديـم الـجـديـده', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'إغـلاق الـتـقـديـم',

                    value:'close'

                },

                {

                    name:'فـتـح الـتـقـديـم',

                    value:'open'

                 

                }

            ]

        }, 
        ]
       },  
    {

    name: 'reset',

    description:'لـتـرسـيـت الـمـقـدمـيـن',

    dm_permission: false,

    admin: true,

    options: [

{

            name: 'panel-type',

            description:'نـوع الـتـقـديـم', 

            type: ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'تـقـديـم الإداره',

                    value:'staff'

                },

                {

                    name:'تـقـديـم الـوسـيـط',

                    value:'mediator'

                 

                }

            ]

        }
        ]
        }, 
    {
        
    name:"message",
        description:'إرسـال رسـالـه لـشـخـص', 
      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
       {

            name: 'message',

            description:'الـرسـالـه', 

            type: ApplicationCommandOptionType.String,

            required: true,

}, 
        
        ]

        
        }, 
    {

        

    name:"temp-role",

        description:'إعـطـاء رتـبـه مـؤقـتـه', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        {

            name: 'role',

            description: 
            'الـرتـبـه', 

            type: ApplicationCommandOptionType.Role,

            required: true,

}, 
        {

            name: 'time',

            description:'وقـت الـرتـبـه', 

            type: ApplicationCommandOptionType.String,

            required: true,

}, 
        
        ]
       }, 
    {

        

    name:"show-temps",

        description:'لـرؤيـه الـرتـب الـمـؤقـتـه لـعـضـو', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        ]
        }, 
    
  {

        

    name:"remove-temp",

        description:'لإزالـه رتـبـه مـؤقـتـه لـعـضـو', 

      dm_permission: false,

    admin: true,

    options: [

{

            name: 'user',

            description:'الـعـضـو', 

            type: ApplicationCommandOptionType.User,

            required: true,

}, 
        {

            name: 'role',

            description:'الـرتـبـه', 

            type: ApplicationCommandOptionType.Role,

            required: true,

}, 
        ]
        }
    
    
];


client.on('interactionCreate', async (i) => {
    if (i.isButton()) {
        const member = i.member;
        switch (i.customId) {
            case "admin": {
                if (member.roles.cache.has(config.staff) || member.roles.cache.has(config.staff2)) {
                    await i.reply({ ephemeral: true, content: '**أنـت إداري بـالـفـعـل**' });
                    return;
                }

                let pom = await db.get('staff_app') || [];
                if (pom.includes(i.user.id)) {
                    await i.reply({ ephemeral: true, content: '**لا يـمـكـنـك الـتـقـديـم مـرتـيـن**' });
                    return;
                }

                const modal = new ModalBuilder()
                    .setCustomId('admin_application')
                    .setTitle('تـقـديـم الإداره');

                const infoInput = new TextInputBuilder()
                    .setCustomId('info')
                    .setLabel('الأسـم و الـعـمـر و الـبـلـد')
                    .setStyle(TextInputStyle.Short)
                    .setMaxLength(50);

                const experienceInput = new TextInputBuilder()
                    .setCustomId('experience')
                    .setLabel('خبراتك')
                    .setStyle(TextInputStyle.Paragraph);

                const adminStatusInput = new TextInputBuilder()
                    .setCustomId('adminStatus')
                    .setLabel('هل كنت اداري بسيرفر اخر او اداري حاليا')
                    .setStyle(TextInputStyle.Paragraph)
                    .setMaxLength(500);

                const activityInput = new TextInputBuilder()
                    .setCustomId('activity')
                    .setLabel('تفاعلك')
                    .setStyle(TextInputStyle.Paragraph)
                    .setMaxLength(100);

                const twoFactorAuthInput = new TextInputBuilder()
                    .setCustomId('twoFactorAuth')
                    .setLabel('هل بتفعل حماية 2FA')
                    .setStyle(TextInputStyle.Paragraph);

                modal.addComponents(
                    new ActionRowBuilder().addComponents(infoInput),
                    new ActionRowBuilder().addComponents(experienceInput),
                    new ActionRowBuilder().addComponents(adminStatusInput),
                    new ActionRowBuilder().addComponents(activityInput),
                    new ActionRowBuilder().addComponents(twoFactorAuthInput)
                );

                await i.showModal(modal);
            } break;
            case "mediator": {
                if (member.roles.cache.has(config.mediator) || member.roles.cache.has(config.mediator2)) {
                    await i.reply({ ephemeral: true, content: '**أنـت وسـيـط بـالـفـعـل**' });
                    return;
                }

                let pom = await db.get('mediator_app') || [];
                if (pom.includes(i.user.id)) {
                    await i.reply({ ephemeral: true, content: '**لا يـمـكـنـك الـتـقـديـم مـرتـيـن**' });
                    return;
                }

                const modal = new ModalBuilder()
                    .setCustomId('mediator_application')
                    .setTitle('تـقـديـم وسـيـط');

                const infoInput = new TextInputBuilder()
                    .setCustomId('info')
                    .setLabel('اسمك و عمرك و بلدك')
                    .setStyle(TextInputStyle.Short)
                    .setMaxLength(50);

                const guidesCountInput = new TextInputBuilder()
                    .setCustomId('guidesCount')
                    .setLabel('كم دليل معك')
                    .setStyle(TextInputStyle.Short);

                const experienceInput = new TextInputBuilder()
                    .setCustomId('experience')
                    .setLabel('خبراتك بالتوسط')
                    .setStyle(TextInputStyle.Paragraph);

                const activityInput = new TextInputBuilder()
                    .setCustomId('activity')
                    .setLabel('تفاعلك')
                    .setStyle(TextInputStyle.Paragraph)
                    .setMaxLength(100);

                const twoFactorAuthInput = new TextInputBuilder()
                    .setCustomId('twoFactorAuth')
                    .setLabel('هل بتفعل حماية 2FA')
                    .setStyle(TextInputStyle.Paragraph);

                modal.addComponents(
                    new ActionRowBuilder().addComponents(infoInput),
                    new ActionRowBuilder().addComponents(guidesCountInput),
                    new ActionRowBuilder().addComponents(experienceInput),
                    new ActionRowBuilder().addComponents(activityInput),
                    new ActionRowBuilder().addComponents(twoFactorAuthInput)
                );

                await i.showModal(modal);
            } break;
            case "reject": {
                await i.deferReply({ ephemeral: true });
const khra = ['1205548791525154867', '1133166513348694106', '464517647497691150'];
                if (!khra.includes(i.user.id)) {
                    await i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**');
                    return;
                }

                let user = await db.get(i.message.id);
                let userr = await client.users.fetch(user);

                let row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('accept')
                        .setLabel('قـبـول')
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('reject')
                        .setLabel('رفـض')
                        .setStyle(ButtonStyle.Danger)
                        .setDisabled(true)
                );

                await i.message.edit({ components: [row], content: `**تـم رفـض الـتـقـديـم بـواسـطـه ${i.user}**` });
                await i.editReply(`**تـم رفـض تـقـديـم <@${user}> بـنـجـاح**`);
                await db.delete(i.message.id);
            }break;
            case "accept": {
                await i.deferReply({ ephemeral: true });
const khra = ['1205548791525154867', '1133166513348694106', '464517647497691150'];
                if (!khra.includes(i.user.id)) {
                    await i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**');
                    return;
                }

                let userid = await db.get(i.message.id);
                let member = await i.guild.members.cache.get(userid);
                if (!member) {
                    await i.editReply('**لـم أسـتـطـع الـعـثـور عـلـي هـذا الـعـضو**');
                    return;
                }

                let userr = await client.users.fetch(userid);
                userr.send({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`**تـم قـبـول تـقـديـمـك بـواسـطـه ${i.user}**`)
                            .setColor('#00ff2b')
                    ],
                    content: `<@${userid}>`
                });

                let row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('accept')
                        .setLabel('تـم قـبـولـه')
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('reject')
                        .setLabel('رفـض')
                        .setStyle(ButtonStyle.Danger)
                        .setDisabled(true)
                );

                await i.message.edit({ components: [row], content: `**تـم قـبـول الـتـقـديـم بـواسـطـه ${i.user}**` });
                await member.roles.add(config.staff);
                await member.roles.add(config.staff2);
                await i.editReply('**تـم قـبـول الـتـقـديـم بـنـجـاح**');
                await db.delete(i.message.id);
            } break;
 case "accept1": {
                await i.deferReply({ ephemeral: true });
const khra = ['1205548791525154867', '1133166513348694106', '464517647497691150'];
                if (!khra.includes(i.user.id)) {
                    await i.editReply('**لا يـمـكـنـك إسـتـخـدام هـذا الأمـر**');
                    return;
                }

                let userid = await db.get(i.message.id);
                let member = await i.guild.members.cache.get(userid);
                if (!member) {
                    await i.editReply('**لـم أسـتـطـع الـعـثـور عـلـي هـذا الـعـضو**');
                    return;
                }

                let userr = await client.users.fetch(userid);
                userr.send({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`**تـم قـبـول تـقـديـمـك بـواسـطـه ${i.user}**`)
                            .setColor('#00ff2b')
                    ],
                    content: `<@${userid}>`
                });

                let row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('accept')
                        .setLabel('تـم قـبـولـه')
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('reject')
                        .setLabel('رفـض')
                        .setStyle(ButtonStyle.Danger)
                        .setDisabled(true)
                );

                await i.message.edit({ components: [row], content: `**تـم قـبـول الـتـقـديـم بـواسـطـه ${i.user}**` });
                await member.roles.add(config.mediator);
                await member.roles.add(config.mediator2);
                await i.editReply('**تـم قـبـول الـتـقـديـم بـنـجـاح**');
                await db.delete(i.message.id);
            } break;
        }
    }

    if (i.type === InteractionType.ModalSubmit) {
        switch (i.customId) {
            case "admin_application": {
                await i.deferReply({ ephemeral: true });

                const info = i.fields.getTextInputValue('info');
                const experience = i.fields.getTextInputValue('experience');
                const adminStatus = i.fields.getTextInputValue('adminStatus');
                const activity = i.fields.getTextInputValue('activity');
                const twoFactorAuth = i.fields.getTextInputValue('twoFactorAuth');

                let channel = await i.guild.channels.cache.get(config.staffchannel);

                let embed = new EmbedBuilder()
                    .setTitle('تـقـديـم إداري')
                    .setDescription(`الـمـقـدم : ${i.user}`)
                    .addFields(
                        { name: 'أسـمـه و عـمـره و بـلـده : ', value: info, inline: true },
                        { name: 'خـبـراتـه : ', value: experience, inline: true },
                        { name: 'هـل كـان إداري بـسـيـرفـر او إداري حـالـيـا : ', value: adminStatus, inline: true },
                        { name: 'تـفـاعـلـه : ', value: activity, inline: true },
                        { name: 'هـل سـيـفـعـل 2FA : ', value: twoFactorAuth, inline: true }
                    );

                let row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('accept')
                        .setLabel('قـبـول')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('reject')
                        .setLabel('رفـض')
                        .setStyle(ButtonStyle.Danger)
                );

                let message = await channel.send({ components: [row], embeds: [embed] });
                await db.set(message.id, i.user.id);

                let po = await db.get('staff_app') || [];
                if (!Array.isArray(po)) {
                    console.error('Error: po is not an array');
                } else {
                    po.push(i.user.id);
                    await db.set('staff_app', po);
                }

                await i.editReply('**تـم إرسـال تـقـديـمـك لـلـمـسؤولـيـن بـنـجـاح**');
            }
            break;
            case "mediator_application": {
                await i.deferReply({ ephemeral: true });

                const info = i.fields.getTextInputValue('info');
                const guidesCount = i.fields.getTextInputValue('guidesCount');
                const experience = i.fields.getTextInputValue('experience');
                const activity = i.fields.getTextInputValue('activity');
                const twoFactorAuth = i.fields.getTextInputValue('twoFactorAuth');

                let channel = await i.guild.channels.cache.get(config.mediatorchannel);

                let embed = new EmbedBuilder()
                    .setTitle('تـقـديـم وسـيـط')
                    .setDescription(`الـمـقـدم : ${i.user}`)
                    .addFields(
                        { name: 'اسـمـه و عـمـره و بـلـده : ', value: info, inline: true },
                        { name: 'كـم دلـيـل مـعـه : ', value: guidesCount, inline: true },
                        { name: 'خـبـراتـه بـالـتـوسـط ( الألـعـاب التي يـقـدـر يـتـوسـط لـهـا و الـبـرامـج) : ', value: experience, inline: true },
                        { name: 'تفاعلك : ', value: activity, inline: true },
                        { name: 'هـل بـتفـعـل حـمـايـه 2fa : ', value: twoFactorAuth, inline: true }
                    );

                let row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('accept1')
                        .setLabel('قـبـول')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('reject')
                        .setLabel('رفـض')
                        .setStyle(ButtonStyle.Danger)
                );

                let message = await channel.send({ components: [row], embeds: [embed] });
                await db.set(message.id, i.user.id);

                let po = await db.get('mediator_app') || [];
                if (!Array.isArray(po)) {
                    console.error('Error: po is not an array');
                } else {
                    po.push(i.user.id);
                    await db.set('mediator_app', po);
                }

                await i.editReply('**تـم إرسـال تـقـديـمـك لـلـمـسؤولـيـن بـنـجـاح**');
            }
            break;
        }
    }
});


const channel = config.tax//ايدي روم التاكس
const line = config.line //رابط الخط




client.on('messageCreate', async (m) => {
  if (m.author.bot) return;
  if (m.channel.id != channel) return;

  let number = parseFloat(m.content);
  if (isNaN(number)) {
    m.reply('**يـرجـي إدخـال رقـم صـحـيـح**');
      await m.channel.send({files:[line]})
    return;
  }
  if (number <= 0) {
    m.reply('**يـرجـي إدخـال رقـم أكـبـر مـن 0**');
      await m.channel.send({files:[line]})
    return;
  }

  if (m.content.endsWith('k') || m.content.endsWith('K')) {
    number *= 1000;
  }

  if (m.content.endsWith('m') || m.content.endsWith('M')) {
    number *= 1000000;
  }

  if (m.content.endsWith('b') || m.content.endsWith('B')) {
    number *= 1000000000;
  }

  let taxx = Math.floor(number * 20 / 19 + 1);
  let row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('mediatorr')
        .setLabel('ضـريـبـه الـوسـيـط')
        .setStyle(ButtonStyle.Secondary)
    );

  let sentMessage = await m.reply({ content: `${taxx}`, components: [row] });
await m.channel.send(`${line}`)
  let filter = (i) => i.user.id === m.author.id && i.message.id === sentMessage.id;
  const collector = m.channel.createMessageComponentCollector({ filter, componentType: ComponentType.Button});

  collector.on('collect', async i => {
    if (i.customId === 'mediatorr') {
      
      let roow = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('back')
            .setLabel('الـعـوده')
            .setStyle(ButtonStyle.Danger)
        );
      await sentMessage.edit({ components: [roow], content: `${Math.floor(taxx * 20 / 19 + 1)} ` });
    }

    if (i.customId === 'back') {
      await sentMessage.edit({ content: `${taxx}`, components: [row] });
    }
  });

  
}); 
const keywords = config.words;

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
const shoppp  = await db.get(`shop_${message.channel.id}`) 
    if (shoppp) {
        const foundKeywords = keywords.filter(word => message.content.includes(word));
        if (foundKeywords.length > 0) {
            const embed = new EmbedBuilder()
                .setTitle('تم العثور على كلمة غير مشفره')
                .setColor('#FF0000')
                .addFields(
                    { name: 'الكلمات غير مشفره:', value: foundKeywords.join(', ') },
                    { name: 'صاحب الرسالة:', value: `<@${await message.author.id}>` },
                    { name: ':الرسالة', value: message.url },
                    { name: 'الروم:', value: message.channel.url }
                );

            const actionRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('admin_button')
                        .setLabel('اضغط لاستلام التحذير')
                        .setStyle(ButtonStyle.Primary)
                );
            const channelToSendId = config.log;
            const channelToSend = await message.guild.channels.fetch(channelToSendId);
            channelToSend.send({ content: '@everyone', embeds: [embed], components: [actionRow] }).then(sentMessage => {
                const filter = (interaction) => interaction.customId === 'admin_button' && interaction.message.id === sentMessage.id;
                const collector = sentMessage.createMessageComponentCollector({ filter, componentType: ComponentType.Button });

                collector.on('collect', async interaction => {
                    const newEmbed = new EmbedBuilder()
                        .setTitle('تم استلام التحذير')
                        .setColor('#00FF00')
                        .setDescription(`تم استلام التحذير بواسطه  <@${await interaction.user.id}>`);

                    const newActionRow = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('admin_button')
                                .setLabel(`تم استلام التحذير بواسطة ${ await interaction.user.username}`)
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(true)
                        );

                    await interaction.update({  components: [newActionRow],content:`**تـم إسـتـلام الـتـحـذيـر بـواسـطـه ${interaction.user}**` });
                    db.add(`shop_${message.channel.id}.warns` , 1)
                    const emb = {

      title: `تـم تـحـذيـر الـمـتـجـر `,

      description: `${message.channel.url} `,

      fields: [

     {

          name: 'الـسـبـب: ',

          value: `عـدم تـشـفـيـر الـكـلـمـات الٱتـيـه  :  ${foundKeywords.join(', ')} `,

          inline: true

        }

          
        

      ],

      

      footer: {

        text: `Dev By : itadori & ra3d`,

      },

      timestamp: new Date(),

    };
const owner = await db.get(`shop_${message.channel.id}`) 
 message.channel.send({embeds:[emb]}) 
     const shopDatta = await db.get(`shop_${message.channel.id}`);
               
               

    
                });
            }).catch(console.error);
        }
    }
});

client2.on('ready', async() => {

console.log('logged in as ' + client2.user.tag)
   
    console.log(`Started refreshing ${commands.length} application (/) commands.`);
   })
client.on('ready', async() => {
const rest = new REST().setToken(config.token);
  try {
    console.log(`Started refreshing ${commands.length} application (/) commands.`);


    const data = await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commands },
    );

    console.log(`Successfully reloaded ${data.length} application (/) commands.`);
  } catch (error) {

    console.error(error);
  }

  
 console.log('logged in as ' + client.user.tag)
})
client.login(config.token)

process.on("unhandledRejection", async e => {

  console.log(e)

})

process.on("uncaughtException", async e => {

  console.log(e)

})

process.on("uncaughtExceptionMonitor", async e => {

  console.log(e)

})

setInterval(async () => {
    const orders = await db.all();
    const now = Math.floor(Date.now() / 1000);
    
    const filteredOrders = orders.filter(order => order.value.channel && order.value.id && order.value.time);

    for (const order of filteredOrders) {
      const { id, channel, time } = order.value;
      if (time < now) {
        try {
          const chan = client.channels.cache.get(channel);
          if (chan) {
            const msg = await chan.messages.fetch(id);
            await msg.delete();
            await db.delete(`order_${id}`);
            console.log(`Deleted message ${id} from channel ${channel}`);
          }
        } catch (error) {
          console.error(`Failed to delete message ${id}:`, error);
            await db.delete(`order_${id}`);
        }
      }
    }
  }, 5000);
async function check() {
    const ke = await db.all()
    const keys = ke.filter(data => data.id.startsWith('roleData_'));
    
    if (!keys.length) return;

    for (const data of keys) {
        const roleData = await db.get(data.id);
        if (!roleData || !roleData.length) continue;

        for (const entry of roleData) {
    
            const guild = client.guilds.cache.get(entry.guild);
            if (!guild) continue;

            const member = guild.members.cache.get(entry.user);
            if (!member) continue;

            const role = guild.roles.cache.get(entry.id);
            if (!role) continue;

            if (Date.now() >= entry.timestamp) {
  console.log('1')
                
                try {
                    await member.roles.remove(role);
                    await db.set(data.id, roleData.filter(d => d.id !== entry.id));
                } catch (err) {
                    const owner = await client.users.fetch('1205548791525154867');
                    const embed = new EmbedBuilder()
                        .setTitle('خـطـأ')
                        .setColor('RED')
                        .setDescription('حـدث خـطـأ لـم أسـتـطـع إزالـه رتـبـه مـؤقـتـه بـسـبـب صـلاحـيـتـي')
                        .addFields(
                            { name: 'الـشـخـص', value: `<@${entry.user}>`, inline: true },
                            { name: 'الـرتـبـه', value: `<@&${role.id}>`, inline: true }
                        );

                    const button = new ButtonBuilder()
                        .setLabel(guild.name)
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true);

                    const row = new ActionRowBuilder().addComponents(button);

                    await owner.send({ embeds: [embed], components: [row] });

                    await db.set(data.id, roleData.filter(d => d.id !== entry.id));
                }
            }
        }
    }
}
setInterval(async () => {
   check()
    
}, 5000);


client.on('messageCreate', async (message) => {
    if (message.content === '!ping') {
        const ping = client.ws.ping;
        const { user, system } = process.cpuUsage();
        const cpuUsageUser = user / 1000000;
        const cpuUsageSystem = system / 1000000;
        const uptime = formatUptime(client.uptime / 1000);

        let status;
        let color;

        if (ping < 50 && (cpuUsageUser + cpuUsageSystem) < 10) {
            status = 'Good';
            color = 0x00FF00;
        } else if (ping < 100 && (cpuUsageUser + cpuUsageSystem) < 20) {
            status = 'Normal';
            color = 0xFFD700;
        } else if (ping < 200 && (cpuUsageUser + cpuUsageSystem) < 40) {
            status = 'Bad';
            color = 0xFF6600;
        } else {
            status = 'Very Bad';
            color = 0xCC0000;
        }

        const embed = new EmbedBuilder()
            .setTitle('Bot Status :')
            .setColor(color)
            .setDescription(`
- Bot Latency: ${ping}ms
- CPU Usage (User): ${cpuUsageUser.toFixed(2)}%
- CPU Usage (System): ${cpuUsageSystem.toFixed(2)}%
- Status: ${status}
- Uptime: ${uptime}
        `);
        
        await message.channel.send({ embeds: [embed] });
    }
});
function formatUptime(seconds) {

    const days = Math.floor(seconds / 86400);

    const hours = Math.floor((seconds % 86400) / 3600);

    const minutes = Math.floor((seconds % 3600) / 60);

    const secondsY = Math.floor(seconds % 60);

    return `${days}d ${hours}h ${minutes}m ${secondsY}s`;

}
const cooldowns = new Map();
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.guild) return;

    const content = message.content.trim().toLowerCase();

    if (content === '!come') {
        return message.reply(`**يـرجـي إسـتـخـدام الأمـر بـطـريقـه صـحـيـحـه مـثـال :\n!come <@${message.author.id}> الـسـبـب(إخـتـيـاري)**`);
    }

    if (content.startsWith('!come')) {
        const args = message.content.slice('!'.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();

        if (command === 'come') {
            if (!message.member.roles.cache.has(config.Admin)&&!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return; 

            const mention = message.mentions.members.first();
            const userID = args[0];
            const reason = args.slice(1).join(' ') || 'لم يتم تحديده';
            const target = mention ? mention.user : userID ? await client.users.fetch(userID).catch(() => null) : null;

            if (!target) {
                return message.reply('**يـرجـي إدخـال أيـدي أو مـنـشـن شـخـص صـالـح**');
            }

            if (target.id === message.author.id) {
                return message.reply('**لا يـمـكـنـك إسـتـدعـاء نـفـسـك**');
            }

            if (cooldowns.has(target.id)) {
                const cooldownTime = cooldowns.get(target.id);
                const remainingTime = (cooldownTime - Date.now()) / 1000;

                if (remainingTime > 0) {
                    return message.reply(`**يـرجـي إنـتـظـار  ${remainingTime.toFixed(1)} ثـانـيـه ثـم إسـتـخـدم الأمـر مـره أخـري**`);
                }
            }

            target.send({
                content: `> **__مرحبًا ,<@${target.id}> !__**\n\n> **__قد تم استدعائك هنا :__** ${message.channel}\n\n> **__من قبل :__** ${message.author}\n\n> **__السبب :__** ${reason}\n\n> **__الرجاء القدوم بسرعه !__**`,
                files: [config.line]
            }).then(() => {
                message.reply('**تـم إرسـال رسـالـة الإسـتـدعـاء بـنـجـاح**');
                cooldowns.set(target.id, Date.now() + 15000);
                setTimeout(() => cooldowns.delete(target.id), 15000);
            }).catch(() => {
                message.reply('**لا يـمـكـنـنـي إرسـال رسـالـه لـهـذا الـعـضـو**');
            });
        }
    }
});
client.on('messageCreate', async (m)  =>  {
    if(m.author.bot) return;
    if (!m.member.roles.cache.has(config.Admin)&&!m.member.permissions.has(PermissionsBitField.Flags.Administrator)) return; 
    if (m.content === `خط`){
   m.delete()
         m.channel.send(`${config.line}`)
        
        } 
    
    })
let Id =  '1205548791525154867'//ايدي الي يتبعتله الرسايل
client.on('messageCreate', async (message) => {

    if (message.channel.type === ChannelType.DM && !message.author.bot) {

        const targetUser = await client.users.fetch(Id);

        const embed = new EmbedBuilder()

            .setTitle('رسـالـه أرسـلـت لـلـبـوت')

            .setDescription(`**الـشـخـص الـذي أرسـل الـرسـالـه: ${message.author.tag} - <@${message.author.id}>\n\nالـرسـالـه: \`${message.content}\`**`);

        targetUser.send({ embeds: [embed] }).catch(error => console.error('Error sending message:', error));

    }

}); 

client2.login('') 